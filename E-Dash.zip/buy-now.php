<!--A Design by W3layouts 
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Edash UV Sanitizer - Product Details</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link rel="shortcut icon" type="image/x-icon" href="images/icon.png">
<!-- Custom Theme files -->
<script src="js/jquery.min.js"></script>
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Machinery Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
					jQuery(document).ready(function($) {
						$(".scroll").click(function(event){		
							event.preventDefault();
							$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
						});
					});
					</script>

<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<link href='//fonts.googleapis.com/css?family=Dosis:400,200,300,500,600,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Righteous' rel='stylesheet' type='text/css'>
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style type="text/css">
	
    hr{
        height: 1px;
        background-color: #ccc;
        border: none;
    }
	#mytextSize
	{
		font-size: 20px;
		line-height: 40px;
		color: #526467;
	}
	.checked {
  color: orange;
	}

	#bottomPadding
	{
		padding-top: 60px;
	}

@media only screen and (max-width: 478px) 
{
	#bottomPadding
	{
		padding-top: 0px;
	}
}





</style>

</head>
<body>
<!--header-->

<?php require_once("header.php"); ?>
<!---->

<!--  <div class="jumbotron jumbotron-fluid" style="background-color: #7fc8d9;">
  <div class="container">
    <h3>How IT Works</h3>
    <p>Home / how it works</p>
  </div>
</div>  -->

<div class="about">

<div class="container">
	<h2 class="text-center" style="font-size: 2.0em;">PRODUCT DETAILS</h2>
	<div class="row">
		<div class="col-md-6 p-0" >

   
    <section class="slider">
           <div class="flexslider">
             <ul class="slides">
				   <li>
				   	<img src="images/buynow/slide1.jpg" class="img-responsive" alt="">

				   </li>
				   <li>
				   	<img src="images/buynow/slide2.jpg" class="img-responsive" alt="">
				   </li>
				   
				   <li>
				   	<img src="images/buynow/slide3.jpg" class="img-responsive" alt="">
				   </li>
				   <li>
				   	<img src="images/buynow/slide4.jpg" class="img-responsive" alt="">
				   </li>
				  
          </ul>
        </div>
      </section>





<!--FlexSlider-->
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
	<script defer src="js/jquery.flexslider.js"></script>
	<script type="text/javascript">
    $(function(){
      SyntaxHighlighter.all();
    });
    $(window).load(function(){
      $('.flexslider').flexslider({
        animation: "slide",
        start: function(slider){
          $('body').removeClass('loading');
        }
      });
    });
  </script>




			<!-- <img src="images/all/product1.jpg" class="img-responsive"> -->
		</div>
		<div class="col-md-6">
			<br>
			<div >
			<h3>UV Sanitizer</h3>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star"></span>
			</div>
			<br>
			<h4 >&#8377; 3999.00</h4>
			<br>
			<div >
			<h4>Product Description </h4><br>
			<p style="font-size: 18px; line-height: 30px;">Introducing <strong>Edash UV-C Sanitizer</strong>, a box-shaped sanitation chamber 
			that uses shot-wavelength UV-C (ultra-violet C) rays to kill 99.99%* viruses including coronavirus, bacteria 
			& fungi from the surface of all inanimate objects exposed to it, like watches, wallets, shoes, mobile phone,
			 keys, cash, mask, vegetables, etc. in just 4 minutes(for commercial use in home & offices) and 8-10 minutes 
			 (for hospital and medical equipment).</p><br>
			<!-- <p><a href="https://pages.razorpay.com/edash" class="btn btn-primary" style="font-size: 18px;">BUY NOW</a></p>
			<p><a href="https://pages.razorpay.com/edash" class="btn btn-primary" style="font-size: 18px;">BUY NOW</a></p>
 -->
 <!--<a href="https://pages.razorpay.com/edash" class="demo-4" style="font-size: 18px;">
   	<span id="uv-buy-btn">
   		<p class="btn btn-primary" id="mybtn">BUY NOW</p>
   	</span>
    </a>-->
    
    <a href="#bulkorder" class="demo-4" style="font-size: 18px;">
   	<span id="uv-buy-btn">
   		<p class="btn btn-primary"  id="mybtn">BULK ORDER</p>
   	</span>
    </a>
			</div>
		</div>
	</div>
	
</div>


</div>

   
<!-- <div class="gallery">

	<div class="container">
	<div class="col-md-4 content-pro-head content-pro-head3">
			<h3>Gallery</h3>
			<p>Many desktop publishing packages and web page editors now use Lorem Ipsum  Ipsum as their default model text now use Lorem Ipsum as their default model text, packages and web page editors now use Lorem Ipsum now use Lorem Ipsum as their default model text, and a as their default model text, lorem ipsum' will uncover many</p>
		
    </div>
  <div class="col-md-8 content-pro-head1">
   		<div class="col-md-6 gallery-top">
			<div class="grid-ga">
			   <a href="images/ga1.jpg" rel="title" class="b-link-stripe b-animate-go  thickbox">

					<figure class="effect-img">
					<img src="images/ga1.jpg" alt=""/>
						<figcaption>
							<h4>Machinery</h4>
							<p>There are many variations of passages of Lorem Ipsum available.</p>	
						</figcaption>	
					</figure>
					</a>
				</div>
		</div>
		<div class="col-md-6 gallery-top">
			<div class="grid-ga">
			   <a href="images/ga.jpg" rel="title" class="b-link-stripe b-animate-go  thickbox">

	
					<figure class="effect-img">
						<img src="images/ga.jpg" alt=""/>
						<figcaption>
							<h4>Machinery</h4>
							<p>There are many variations of passages of Lorem Ipsum available.</p>	
						</figcaption>			
					</figure>
					</a>
				</div>
		</div>
		<div class="col-md-4 gallery-top">
			<div class="grid-ga">
			   <a href="images/ga2.jpg" rel="title" class="b-link-stripe b-animate-go  thickbox">


					<figure class="effect-img">
						<img src="images/ga2.jpg" alt=""/>
						<figcaption class="ga-text">
							<h4 >Machinery</h4>
							<p>There are many variations.</p>	
						</figcaption>			
					</figure>
					</a>
				</div>
		</div>
		<div class="col-md-4 gallery-top">
			<div class="grid-ga">
			   <a href="images/ga1.jpg" rel="title" class="b-link-stripe b-animate-go  thickbox">


					<figure class="effect-img">
						<img src="images/ga1.jpg" alt=""/>
						<figcaption class="ga-text">
							<h4 >Machinery</h4>
							<p>There are many variations.</p>	
						</figcaption>			
					</figure>
					</a>
				</div>
		</div>
		<div class="col-md-4 gallery-top">
			<div class="grid-ga">
			   <a href="images/ga3.jpg" rel="title" class="b-link-stripe b-animate-go  thickbox">
					<figure class="effect-img">
						<img src="images/ga3.jpg" alt=""/>
						<figcaption class="ga-text">
							<h4 >Machinery</h4>
							<p>There are many variations.</p>	
						</figcaption>			
					</figure>
					</a>
				</div>
		</div>
		<div class="col-md-6 gallery-top">
			<div class="grid-ga">
			   <a href="images/ga4.jpg" rel="title" class="b-link-stripe b-animate-go  thickbox">
					<figure class="effect-img">
						<img src="images/ga4.jpg" alt=""/>
						<figcaption>
							<h4>Machinery</h4>
							<p>There are many variations of passages of Lorem Ipsum available.</p>	
						</figcaption>			
					</figure>
					</a>
				</div>
		</div>
		<div class="col-md-6 gallery-top">
			<div class="grid-ga">
			   <a href="images/ga5.jpg" rel="title" class="b-link-stripe b-animate-go  thickbox">
					<figure class="effect-img">
						<img src="images/ga5.jpg" alt=""/>
						<figcaption>
							<h4>Machinery</h4>
							<p>There are many variations of passages of Lorem Ipsum available.</p>	
						</figcaption>			
					</figure>
					</a>
				</div>
		</div>
		<div class="clearfix"> </div>
  </div>
  
	<div class="clearfix"> </div>
	</div>
</div> -->


<div class="container p-2">

<div class="row">

<div class="page-header">
        <h1>Product Specifications</h1>
      </div>
  
  <table style="height: 593px; width: 100%; border-collapse: collapse; border-style: solid; border-color: grey; background-color: blue; margin-left: auto; margin-right: auto;" border="1">
<tbody>
<tr style="height: 53px;">
<td style="width: 50%; height: 53px; background-color: #050a30;">
<h3 style="text-align: center;"><span style="color: #ffffff;">Product Specification</span></h3>
</td>
<td style="width: 50%; height: 53px; background-color: #050a30; text-align: left;">
<h3 style="text-align: center;"><span style="color: #ffffff;">Edash UV sanitizer</span></h3>
</td>
</tr>
<tr style="height: 54px; text-align: left;">
<td style="width: 50%; height: 54px; background-color: #050a30;">
<h4 style="padding-left: 40px;"><span style="color: #ffffff;">Capacity</span></h4>
</td>
<td style="width: 50%; height: 54px; background-color: white; text-align: center;">
<h4>34 Liter</h4>
</td>
</tr>
<tr style="height: 54px; text-align: left;">
<td style="width: 50%; height: 54px; background-color: #050a30;">
<h4 style="padding-left: 40px;"><span style="color: #ffffff;">Power Consumption</span></h4>
</td>
<td style="width: 50%; height: 54px; background-color: white; text-align: center;">
<h4>22 W</h4>
</td>
</tr>
<tr style="height: 54px; text-align: left;">
<td style="width: 50%; height: 54px; background-color: #050a30;">
<h4 style="padding-left: 40px;"><span style="color: #ffffff;">Outer Dimensions(L x W x H)</span></h4>
</td>
<td style="width: 50%; background-color: white; height: 54px; text-align: center;">
<h4>50x30x30 cm</h4>
</td>
</tr>
<tr style="height: 54px; text-align: left;">
<td style="width: 50%; height: 54px; background-color: #050a30;">
<h4 style="padding-left: 40px;"><span style="color: #ffffff;">Inner Dimensions(L x W x H)</span></h4>
</td>
<td style="width: 50%; background-color: white; height: 54px; text-align: center;">
<h4>40x29x29 cm</h4>
</td>
</tr>
<tr style="height: 54px; text-align: left;">
<td style="width: 50%; height: 54px; background-color: #050a30;">
<h4 style="padding-left: 40px;"><span style="color: #ffffff;">Inner construction</span></h4>
</td>
<td style="width: 50%; height: 54px; background-color: white; text-align: center;">
<h4>Mirror finish stainless steel</h4>
</td>
</tr>
<tr style="height: 54px; text-align: left;">
<td style="width: 50%; height: 54px; background-color: #050a30;">
<h4 style="padding-left: 40px;"><span style="color: #ffffff;">Outer construction</span></h4>
</td>
<td style="width: 50%; height: 54px; background-color: white; text-align: center;">
<h4>Powder Coated CRCA</h4>
</td>
</tr>
<tr style="height: 54px; text-align: left;">
<td style="width: 50%; height: 54px; background-color: #050a30;">
<h4 style="padding-left: 40px;"><span style="color: #ffffff;">Electrical supply required</span></h4>
</td>
<td style="width: 50%; height: 54px; background-color: white; text-align: center;">
<h4>1ph,220-240v,50Hz</h4>
</td>
</tr>
<tr style="height: 54px; text-align: left;">
<td style="width: 50%; height: 54px; background-color: #050a30;">
<h4 style="padding-left: 40px;"><span style="color: #ffffff;">No. of uv-c lamps</span></h4>
</td>
<td style="width: 50%; height: 54px; background-color: white; text-align: center;">
<h4>2 no.</h4>
</td>
</tr>
<tr style="height: 54px; text-align: left;">
<td style="width: 50%; height: 54px; background-color: #050a30;">
<h4 style="padding-left: 40px;"><span style="color: #ffffff;">Life of uv-c lamp</span></h4>
</td>
<td style="width: 50%; height: 54px; background-color: white; text-align: center;">
<h4>11000 hours</h4>
</td>
</tr>
<tr style="height: 54px; text-align: left;">
<td style="width: 50%; height: 54px; background-color: #050a30;">
<h4 style="padding-left: 40px;"><span style="color: #ffffff;">Recommended Disinfecting Cycle</span></h4>
</td>
<td style="width: 50%; height: 54px; background-color: white; text-align: center;">
<h4>1-10 mins. Varys as per application</h4>
</td>
</tr>
</tbody>
</table>
  </div>

</div>


</div>




<div class="container">

<div class="row">

<table class="table">
 
 <thead>
   <tr>
  <br>
	 <th><h3>Steps to use</h3></th>
	
	 
   </tr>
  
   <td>
	   <h4>How to use a UVC Sanitizer ?</h4><br>
	   <p  class="para" style="font-size: 20px;line-height:35px;">

	   1. Plug in to your 230 V electric board<br>
			2. Press the red button to on UV sanitizer (it glows to RED)<br>
			3. Pull led of box & put what you want to sanitize<br>
			3. Touch the power button "c-" after set time (default time is 4 min)<br>
			4. If you are using for medical purpose set to 8-10 min(OPTIONAL)<br>
			6. Touch the set button to start<br>
			7. That's it
	   </p><br>
 


	   <h4>Warranty of 6 Months</h4><br>
	   <p  class="para" style="font-size: 20px;line-height:35px;">

	   It has 6 months of warranty and uv lamp has 2 months of warranty
			The warranty of uv-c sanitizer is covered only in case of 
			electronics & electrical failure "NO PHYSICAL DAMEGE IS COVERED"
	   </p>
	   </td>
 </thead>
 <tbody>


   
 </tbody>
</table>

</div>

</div>

<div class="about" id="bulkorder">

	<div class="container">
	<div class="col-md-4 ">
			<h3>Bulk Order</h3><br>
			<p  class="para" style="font-size: 20px;line-height:35px;">Now you can also buy edash UV sanitizer in bulk . 
			Please fill the form that we can connect with you shortly.</p>
		
    </div>
  <div class="col-md-8 content-pro-head1">
  <form action="bulkorderprocess.php" method="post" >
  <div class="form-row">
	  
    <div class="form-group col-md-6">
      <label for="inputEmail4">Name</label>
      <input type="text" class="form-control" id="inputEmail4" name="name" placeholder="Name" required>
	</div>
	<div class="form-group col-md-6">
      <label for="inputEmail4">Email</label>
      <input type="email" class="form-control" id="inputEmail4" name="email" placeholder="Email" required>
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Phone</label>
      <input type="number" class="form-control" id="inputPassword4" name="phone" placeholder="Phone number" required>
    </div>
  </div>
  <div class="form-group col-md-6">
      <label for="inputZip">Pincode</label>
      <input type="text" class="form-control" name="pincode" id="inputZip" placeholder="Pincode" required>
    </div>
  <div class="form-group col-md-12">
    <label for="inputAddress">Address of delivery</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" name="address" placeholder="Address of delivery" rows="3" required></textarea>
  </div>
  <div class="form-group col-md-6">
      <label for="inputState">City</label>
	  <input type="text" class="form-control" id="inputEmail4" name="city" placeholder="City" required>
    </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="amount">Quantity</label>
      <input type="number" name="amount" class="form-control" id="amount" placeholder="Quantity" required>
    </div>
    
    
  </div>
  <div class="form-group col-md-6">
  <button type="submit" class="btn btn-primary">SUBMIT</button>
</div>
</form>

	
  
	<div class="clearfix"> </div>
	</div>
</div>


<!-- <div class="about">
<div class="container">

<h3></h3>
<p>Now yoy can also buy edash UV sanitizer in bulk.Please fill the below form that we can connect with you shortly.</p>
<div class="row">

<div class="col-md-12">

<form>
  <div class="form-row">
	  
    <div class="form-group col-md-6">
      <label for="inputEmail4">Name</label>
      <input type="text" class="form-control" id="inputEmail4" name="name" placeholder="Email">
	</div>
	<div class="form-group col-md-6">
      <label for="inputEmail4">Email</label>
      <input type="email" class="form-control" id="inputEmail4" name="email" placeholder="Email">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Phone</label>
      <input type="number" class="form-control" id="inputPassword4" name="phone" placeholder="Password">
    </div>
  </div>
  <div class="form-group col-md-6">
      <label for="inputZip">Pincode</label>
      <input type="text" class="form-control" name="pincode" id="inputZip">
    </div>
  <div class="form-group">
    <label for="inputAddress">Address of delivery</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" name="address" rows="3"></textarea>
  </div>
  <div class="form-group col-md-6">
      <label for="inputState">City</label>
      <select id="inputState" name="city" class="form-control">
        <option selected>Choose...</option>
        <option>Aurangabad</option>
      <option>Nashik</option>
      <option>Thane</option>
      <option>Sangli</option>
	  <option>Amaravati</option>
	  <option>Chandrapur</option>
      <option>Pune</option>
      <option>Nagpur</option>
      <option>Kolhapur</option>
	  <option>Ratnagiri</option>
	  <option>Solapur</option>
      <option>Buldhana</option>
      <option>Jalgaon</option>
      <option>Mumbai</option>
      </select>
    </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputCity">Amount</label>
      <input type="number" name="amount" class="form-control" id="inputCity">
    </div>
    
    
  </div>
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>

</div>

</div>
</div>

</div> -->



</div>



	<script src="js/jquery.chocolat.js"></script>
		<link rel="stylesheet" href="css/chocolat.css" type="text/css" media="screen" charset="utf-8">
		<!--light-box-files -->
		<script type="text/javascript" charset="utf-8">
		$(function() {
			$('.grid-ga a').Chocolat();
		});
		</script>

<script>

/* Demo Scripts for Bootstrap Carousel and Animate.css article
*/
(function( $ ) {

//Function to animate slider captions 
function doAnimations( elems ) {
  //Cache the animationend event in a variable
  var animEndEv = 'webkitAnimationEnd animationend';
  
  elems.each(function () {
    var $this = $(this),
      $animationType = $this.data('animation');
    $this.addClass($animationType).one(animEndEv, function () {
      $this.removeClass($animationType);
    });
  });
}

//Variables on page load 
var $myCarousel = $('#carousel-example-generic'),
  $firstAnimatingElems = $myCarousel.find('.item:first').find("[data-animation ^= 'animated']");
  
//Initialize carousel 
$myCarousel.carousel();

//Animate captions in first slide on page load 
doAnimations($firstAnimatingElems);

//Pause carousel  
// $myCarousel.carousel('pause');


//Other slides to be animated on carousel slide event 
$myCarousel.on('slide.bs.carousel', function (e) {
  var $animatingElems = $(e.relatedTarget).find("[data-animation ^= 'animated']");
  doAnimations($animatingElems);
});  

})(jQuery);

</script>
<!--footer-->

<?php require_once("footer.php"); ?>

<!--footer-->
<!-- for bootstrap working -->
	<script src="js/bootstrap.min.js"></script>
	<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<!-- //for bootstrap working -->

</body>
</html>
<script>
  AOS.init();
</script>