<div class="footer">
	<div class="footer-grids" style="padding: 30px 0;">
		<div class="container">
				<div class="col-md-4 footer-grid" style="padding: 0px;">
					<div class="footer-grid1">
						<div class="con-ic">
							<i class="glyphicon glyphicon-map-marker" aria-hidden="true"></i>
						</div>
						
							<h4>Address</h4>
							<p style="font-size: 18px;">Vijapur road , solapur - 413004 </p>
						
					</div>
				</div>
				<div class="col-md-4 footer-grid " style="padding: 0px;">
					<div class="footer-grid1">
						<div class="con-ic">
							<i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>
					</div>
							<h4>Call Us</h4>
							<p style="font-size: 18px;"><span><a href="tel:+91 9834657170">+91 9834657170</a></span></p>
						
					</div>
				</div>
				<div class="col-md-4 footer-grid " style="padding: 0px;">
					<div class="footer-grid1">
						<div class="con-ic">
							<i class="glyphicon glyphicon-envelope" aria-hidden="true"></i>
						</div>
							<h4>Email</h4>
							<p style="font-size: 18px;"><a href="mailto:sales@e-dash.in">sales@e-dash.in</a></p>
							<p style="font-size: 18px;"><a href="mailto:info@e-dash.in">info@e-dash.in</a></p>
							<p style="font-size: 18px;"><a href="mailto:Support@e-dash.in">Support@e-dash.in</a></p>
							<!-- Support@e-dash.in -->
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
	</div>
	<div class="footer-bottom" id="footer" style="padding-top:50px;">
<div class="container">

<div class="row">

<div class="col-md-4">

<h3 style="color:#fff;text-align:left"> Edash UV Sanitizer</h3><br>

<p style="color:#fff;text-align:left;line-height:30px">Introducing <strong>Edash UV-C Sanitizer
				</strong>, a box-shaped sanitation chamber that uses short-wavelength UV-C (ultra-violet C) rays 
				to kill 99.99%* viruses</p>
</div>

<div class="col-md-4">

<h3 style="color:#fff;text-align:left"> Quick Links</h3><br>

<p style="text-align:left;padding-bottom:5px" ><a style="color:#fff;text-decoration:none;" href="index.php">Home</a></p>
<p style="text-align:left;padding-bottom:5px" ><a style="color:#fff;text-decoration:none;" href="about.php">About</a></p>
<p style="text-align:left;padding-bottom:5px" ><a style="color:#fff;text-decoration:none;" href="how-it-works.php">Product</a></p>

<p style="text-align:left;padding-bottom:5px" ><a style="color:#fff;text-decoration:none;" href="contact.php">Support</a></p>
<p style="text-align:left;padding-bottom:5px" ><a style="color:#fff;text-decoration:none;" href="buy-now.php">Bulk Order</a></p>

</div>

<div class="col-md-4">

<div class="bs-example " data-example-id="simple-horizontal-form">
<form class="form-horizontal" action="footerform.php" method="post">
      <div class="form-group">
     
        <div class="col-sm-10">
          <input type="text" class="form-control" id="inputEmail3" name="name" placeholder="Enter Name" required>
        </div>
      </div>
      <div class="form-group">
      
        <div class="col-sm-10">
          <input type="email" class="form-control" id="inputPassword3" name="email" placeholder="Enter Email address" required>
        </div>
      </div>
  
	  <div class="form-group">
      
	  <div class="col-sm-10">
		<input type="number" class="form-control" maxlength="10" id="inputPassword3" name="phone" placeholder="Enter Contact number" required>
	  </div>
	</div>

	<div class="form-group">
	<div class="col-sm-10">
    <input type="text" class="form-control" id="inputEmail3" placeholder="Enter Location & Requirement" name="city" required>
  </div>
  </div>
  <div class="form-group">
  <div class="col-sm-10">  
						<input type="submit" name="btn-subscribe" class="btn btn-block btn-primary" value="Enquire Now">
					</div>
					</div>
	</form>
	
  </div>

</div>
<div class="copy">
			<p style="color:#fff;">© Copyright 2020 All rights reserved | Designed & Developed by  <a href="https://www.equireitpark.com/" target="_blank" style="color: white;">Equire IT Park</a> </p>
		</div>
</div>
		</div>
		
	<!--	</div>
		
		</div>
	</div>
</div>-->