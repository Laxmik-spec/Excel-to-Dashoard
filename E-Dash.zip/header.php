<style type="text/css">
  body
  {
    overflow-x: hidden;
  }
  div.sticky {
  position: -webkit-sticky;
  position: sticky;
   background-color: yellow;
  top: 0;
}
#mobile
{
  display: none;
}
.navbar-header
{
  padding: 20px;
}
#uv-buy-btn
{
  padding-top: 12px; 
  padding-left: 10px;
}
#textSize
{
  font-size: 18px;
}
@media only screen and (max-width: 478px) 
{
  #desktop
  {
    display: none;
  }
  #mobile
  {
    display: block;
  }
  .navbar-header
  {
    padding: 0px;
  }
  #uv-buy-btn
  {
    padding-top: 12px; 
    padding-left: 0px;
  }
  #mybtn
  {
    padding: 8px 18px;
  }
  .demo-4 {
  width: 120px;   
  background-color: transparent;    
  cursor: pointer;  
  border-color: #12A7CA; 
  }
}
</style>

<div class="header" id="top">
<!-- <div class="header-top">
	<div class="container">
		<ul class="head-left">
			<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>+123456789</li>
			<li><span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>05-mirus Road,Dlowa GSRT</li>
		</ul>
		<div class="head-right">
		<ul class="social-ic">
			<li><a href="#"><i></i></a></li>
			<li><a href="#"><i class="ic"></i></a></li>
			<li><a href="#"><i class="ic1"></i></a></li>
			<li><a href="#"><i class="ic2"></i></a></li>
		</ul>
		</div>
		<div class="clearfix"> </div>
	</div>
</div> -->

<!---->
	<div class="container" >
<nav class="navbar navbar-default">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
					  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					  </button>
						 <div class="navbar-brand logo ">
							<!-- <h1 class="animated wow pulse" data-wow-delay=".5s"> -->
							 <img src="images/logo/logo_trans.png" id="desktop" width="120" height="120" style="margin-top: -60px;"> 

              <img src="images/logo/logo_trans.png" id="mobile" width="120" height="120" style="margin-top: -30px; margin-left: -20px;">
            <!-- </h1> -->
						</div>
<div class="clearfix"></div>
					</div>

					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse nav-wil links" id="bs-example-navbar-collapse-1">
					<div class="top-nav">
    <a href="index.php" class="demo-4 ">
      <span>
        <span>Home</span>
        <span>Home</span>
        <span></span>
      </span>
    </a>

    <a href="how-it-works.php" class="demo-4">
      <span>
        <span>Product</span>
        <span>Product</span>
        <span></span>
      </span>
    </a>

    <a href="about.php" class="demo-4">
      <span>
        <span>About</span>
        <span>About</span>
        <span></span>
      </span>
    </a>
<!-- 	<a href="gallery.html" class="demo-4">
      <span>
        <span>Support</span>
        <span>Support</span>
        <span></span>
      </span>
    </a> -->
   <!--    <a href="codes.html" class="demo-4">
      <span>
        <span>Codes</span>
        <span>Codes</span>
        <span></span>
      </span>
    </a> -->

<a href="contact.php" class="demo-4">
      <span>
        <span>Support</span>
        <span>Support</span>
        <span></span>
      </span>
    </a>
   





   <!-- <a href="contact.php" class="demo-4" style="font-size: 18px;">
      <span>
        <span>Support</span>
        <span>Support</span>
        <span></span>
      </span>
    </a>-->
<!--     <a href="buy-now.php" class="demo-4" style="font-size: 18px;">
   	<span id="uv-buy-btn">
   		<p class="btn btn-primary" id="mybtn">BUY NOW</p>
   	</span>
    </a>-->
    
    <a href="info.pdf" class="demo-4" style="font-size: 18px;">
   	<span id="uv-buy-btn">
   		<p class="btn btn-primary" id="mybtn">BROCHURE</p>
   	</span>
    </a>

    

  </div>
					</div><!-- /.navbar-collapse -->
				</nav>
				</div>
</div>