
<!-- rich_wood@rediffmail.com -->
<?php
error_reporting(0);
    $to = "edashelectronic@gmail.com";
    $from = $_POST['email'];
    $name = $_POST['name'];
    // $address= $_POST['address'];
    $phone = $_POST['phone'];
    $city = $_POST['city'];
    // $pincode = $_POST['pincode'];
    // $amount = $_POST['amount'];
    $subject = $_POST['subject'];
    // $moblie = $_POST['no'];
	$var = $_POST['taskOption'];
    $headers = "From: $from";
	$headers = "From: " . $from . "\r\n";
	$headers .= "Reply-To: ". $from . "\r\n";
	$headers .= "MIME-Version: 1.0\r\n";
	$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

    $subject = "You have a message ";

    $logo = 'assets/images/logo.png';
    $link = '#';

	$body = "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'><title>Express Mail</title></head><body>";
	$body .= "<table style='width: 100%;'>";
	$body .= "<thead style='text-align: center;'><tr><td style='border:none;' colspan='2'>";
	$body .= "<a href='{$link}'><img src='{$logo}' alt=''></a><br><br>";
	$body .= "</td></tr></thead><tbody><tr>";
	$body .= "<td style='border:none;'><strong>Name:</strong> {$name}</td>";
    $body .= "<td style='border:none;'><strong>Email Address:</strong> {$from}</td>";
    $body .= "<td style='border:none;'><strong>Contact no:</strong> {$phone}</td>";
    // $body .= "<td style='border:none;'><strong>Address of delivery:</strong> {$address}</td>";
    $body .= "<td style='border:none;'><strong>City:</strong> {$city}</td>";
    // $body .= "<td style='border:none;'><strong>Pincode:</strong> {$pincode}</td>";
	// $body .= "<td style='border:none;'><strong>Amount:</strong> {$amount}</td>";
	$body .= "<td style='border:none;'><strong>Email:</strong> {$from}</td>";
	$body .= "</tr>";
	$body .= "<tr><td style='border:none;'><strong>Subject:</strong> {$subject}</td></tr>";
	$body .= "<tr><td></td></tr>";
	$body .= "<tr><td colspan='2' style='border:none;'>{$no}</td></tr>";
	$body .= "</tbody></table>";
	$body .= "</body></html>";

	
	$send = mail($to, $subject, $body, $headers);
	if($send){

?>
<script>
	alert("We have received your message and would like to thank you for writing to us.If your inquiry is urgent call +91 9834657170");
	window.location.href = "buy-now.php#footer";
</script>
<?php
	}
else{

?>
<script>

	alert("Something went worng");
	window.location.href = "buy-now.php#footer";
</script>
<?php
}

?>

