<!--A Design by W3layouts 
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Edash UV Sanitizer - About</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<script src="js/jquery.min.js"></script>
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<link rel="shortcut icon" type="image/x-icon" href="images/icon.png">
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Machinery Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
					jQuery(document).ready(function($) {
						$(".scroll").click(function(event){		
							event.preventDefault();
							$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
						});
					});
					</script>

<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

<!-- <script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script> -->
<!--//end-animate-->
<link href='//fonts.googleapis.com/css?family=Dosis:400,200,300,500,600,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Righteous' rel='stylesheet' type='text/css'>
	<script type="text/javascript">
							$(window).load(function() {
								$("#flexiselDemo1").flexisel({
									visibleItems: 3,
									animationSpeed: 1000,
									autoPlay: true,
									autoPlaySpeed: 3000,    		
									pauseOnHover: true,
									enableResponsiveBreakpoints: true,
									responsiveBreakpoints: { 
										portrait: { 
											changePoint:480,
											visibleItems: 1
										}, 
										landscape: { 
											changePoint:640,
											visibleItems: 2
										},
										tablet: { 
											changePoint:991,
											visibleItems: 2
										}
									}
								});
								
							});
					</script>
		<script type="text/javascript" src="js/jquery.flexisel.js"></script>

<style type="text/css">
	#mytextSize
	{
		font-size: 20px;
		line-height: 40px;
		color: #526467;
	}
</style>

</head>
<body>
<!--header-->

<?php require_once("header.php"); ?>

<!---->
<div class="jumbotron jumbotron-fluid" style="background-color: #7DD5F6;">
  <div class="container">
    <h3 style="font-size: 2.0em;">About Us</h3>
    <p>Home / About</p>
  </div>
</div>
   
<div>

	<div class="container">
	  <div class="col-md-4 content-pro-head1">
	   		<div class="col-md-12 about-im" >
				<img src="images/about.jpg" class="img-responsive" alt=" ">
			</div>
		<!-- 	<div class="col-md-6 about-im">
				<img src="images/a2.jpg" class="img-responsive" alt=" ">
			</div> -->
			<div class="clearfix"> </div>
	 </div>
	<div class="col-md-8 content-pro-head content-pro-head3">
		<br><br>
			<!-- <h3>About</h3> -->
			<p id="mytextSize" style="text-align:justify;">Edash is a R & D and production based startup. We develop our products from scratch 
				till end delivery for home & industry. We develop products in electronics and electrical sector.
			At edash quality is our mission. No matter what you’re looking for, we’re committed to bringing you 
			exactly what you need, when you need it. Our customers love working with us because we produce 
			high-quality products with an exceptionally fast turnaround.
			We are for humanity not a business.
			</p>
			<!-- <p><a href="buy-now.php" class="btn btn-primary ">BUY NOW</a></p> -->
		
    </div>
  
  
	<div class="clearfix"> </div>
	</div>
</div>



	<div style="padding-top: 40px; padding-bottom: 40px;">
	<div class="container text-center">
		<div class="col-md-12 ser-grid " >
			<!-- <div class="social">
				<a href="#" class="link facebook" ><span class="glyphicon glyphicon-fire "> </span></a>
			</div> -->
				<h5 style="font-size: 2.2em;">Management Message</h5>
				<br>
				<p id="mytextSize">
					We are right now like one drop of sea, our presence doesn't matters. But if we succeed to make 
					timeless brand, we definitely revolutionize this world.<br>
          			  <b>-N.Rathod</b>
			</p>
		</div>
	</div>
</div>




<!---->
<!-- <div class="why">

	<div class="container">
	
	<div class="content-pro-head why-head text-center">
			<h3>Why Choose Us</h3>
		
    </div><br><br><br>
	<div class="row">
  <div class="col-md-12 content-pro-head1">

  <div class="col-md-4 why-text ">
					<i class="glyphicon glyphicon-usd "> </i>
					<h4>Cost Effective</h4>
					<p>we keep less profitable margin on our products.Because our goal is to provide best cost efficient products in market to buy all categories of people.</p>
				</div>
   				
				
				<div class="col-md-4 why-text ">
					<i class="glyphicon glyphicon-ok"> </i>
					<h4>Quality</h4>
					<p>we never compromise with our product quality to build.</p>
				</div>
				<div class="col-md-4 why-text ">
					<i class="glyphicon glyphicon-user"> </i>
					<h4>Team Work</h4>
					<p>Our team is one of the refined team to make our products in timeline.</p>
				</div>
				<div class="col-md-4 why-text ">
					<i class="glyphicon glyphicon-flag"> </i>
					<h4>After Market Service</h4>
					<p>we provide warranty period support and after warranty as well.</p>
				</div>

				

				<div class="col-md-4 why-text ">
					<i class="glyphicon glyphicon-thumbs-up "> </i>
					<h4>Helping Hand</h4>
					<p>We make this product to help society and community to over come from this COVID-19 situation.And keep less profitable margin.</p>
				</div>

				
		<div class="clearfix"> </div>
  </div>

	<div class="clearfix"> </div>
	</div>
</div> -->
<!---->

  <!---->
<!--  <div class="content-pro">
	<div class="container">
		<div class="col-md-4 content-pro-head content-pro-head2">
			<h3>Our Services</h3>
			<p>Many desktop publishing packages and web page editors now use Lorem Ipsum  Ipsum as their default model text now use Lorem Ipsum as their default model text, packages and web page editors now use Lorem Ipsum now use Lorem Ipsum as their default model text, and a as their default model text, lorem ipsum' will uncover many</p>
		
    </div>
  <div class="col-md-8 content-pro-head1">
   	<ul id="flexiselDemo1">			
				<li>
					<div class="laptop">
							<div class="img-box"><img class="img-responsive zoom-img" src="images/pi.jpg" alt=" " /></div>
							<div class="flex-info ">
									<h4>Services1</h4>
									<p>Sit accusamus, vel blanditiis iure minima ipsa molestias minus laborum velit, nulla nisi hic quasi enim.</p>
							</div>
						</div>
					
				</li>
				<li>
					<div class="laptop">
							<div class="img-box"><img class="img-responsive zoom-img" src="images/pi1.jpg" alt=" " /></div>
							<div class="flex-info flex-info1">
									<h4>Services2</h4>
									<p>Sit accusamus, vel blanditiis iure minima ipsa molestias minus laborum velit, nulla nisi hic quasi enim.</p>
							</div>
						</div>
					
				</li>
				<li>
					<div class="laptop">
							<div class="img-box"><img class="img-responsive zoom-img" src="images/pi2.jpg" alt=" " /></div>
							<div class="flex-info flex-info2">
									<h4>Services3</h4>
									<p>Sit accusamus, vel blanditiis iure minima ipsa molestias minus laborum velit, nulla nisi hic quasi enim.</p>
							</div>
							</div>
						
				</li>
				<li>
					<div class="laptop">
							<div class="img-box"><img class="img-responsive zoom-img" src="images/pi3.jpg" alt=" " /></div>
							<div class="flex-info flex-info3">
									<h4>Services4</h4>
									<p>Sit accusamus, vel blanditiis iure minima ipsa molestias minus laborum velit, nulla nisi hic quasi enim.</p>
							</div>
							</div>
						
				</li>
			</ul>
		
  </div>
	<div class="clearfix"> </div>
	</div>
</div> -->
<!---->
<!---->
 <!-- <div class="content-pro content-pro1" style="padding-top: 40px;">
	<div class="container">
	<div class="col-md-4 content-pro-head team-t">
			<h3>Our Team</h3>
			<p>Many desktop publishing packages and web page editors now use Lorem Ipsum  Ipsum as their default model text now use Lorem Ipsum as their default model text, packages and web page editors now use Lorem Ipsum now use Lorem Ipsum as their default model text, and a as their default model text, lorem ipsum' will uncover many</p>
		
    </div>
  <div class="col-md-8 content-pro-head1 team-t1">
   	<div class="col-md-4 bottom-grid ">
			<div class="btm-right">
				<img src="images/te.jpg" class="img-responsive" alt=" ">
					<div class="captn">						
							<h4>Victoria</h4>
							<p>Ceo</p>
						<ul class="social-ic">
			<li><a href="#"><i></i></a></li>
			<li><a href="#"><i class="ic"></i></a></li>
			<li><a href="#"><i class="ic1"></i></a></li>
			<li><a href="#"><i class="ic2"></i></a></li>
		</ul>
					</div>
			</div>
		</div>
		<div class="col-md-4 bottom-grid ">
			<div class="btm-right">
				<img src="images/te1.jpg" class="img-responsive" alt=" ">
					<div class="captn">
					
							<h4>Adley</h4>
						<p>Manager</p>
						<ul class="social-ic">
			<li><a href="#"><i></i></a></li>
			<li><a href="#"><i class="ic"></i></a></li>
			<li><a href="#"><i class="ic1"></i></a></li>
			<li><a href="#"><i class="ic2"></i></a></li>
		</ul>
					</div>
			</div>
		</div>
		<div class="col-md-4 bottom-grid ">
			<div class="btm-right">
				<img src="images/te2.jpg" class="img-responsive" alt=" ">
					<div class="captn">
						
							<h4>Immortal</h4>
						<p>Engineer</p>
						<ul class="social-ic">
			<li><a href="#"><i></i></a></li>
			<li><a href="#"><i class="ic"></i></a></li>
			<li><a href="#"><i class="ic1"></i></a></li>
			<li><a href="#"><i class="ic2"></i></a></li>
		</ul>
					</div>
			</div>
		</div>

  </div>
  
	<div class="clearfix"> </div>
	</div>
</div> -->
<!--//-->
<!--footer-->

<?php require_once("footer.php"); ?>

<!--footer-->
<!-- for bootstrap working -->
	<script src="js/bootstrap.min.js"></script>
	<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<!-- //for bootstrap working -->

</body>
</html>
<script>
	  AOS.init();
</script>