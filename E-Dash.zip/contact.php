<!--A Design by W3layouts 
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Edash UV Sanitizer - Contact</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link rel="shortcut icon" type="image/x-icon" href="images/icon.png">
<!-- Custom Theme files -->
<script src="js/jquery.min.js"></script>
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Machinery Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
					jQuery(document).ready(function($) {
						$(".scroll").click(function(event){		
							event.preventDefault();
							$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
						});
					});
					</script>

<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<link href='//fonts.googleapis.com/css?family=Dosis:400,200,300,500,600,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Righteous' rel='stylesheet' type='text/css'>

</head>
<body>
<!--header-->

<?php require_once("header.php"); ?>

<!---->


<div clss="container">
 <div class="jumbotron jumbotron-fluid" style="background-color: #7DD5F6;">
 <div class="container">
    <h3 style="font-size: 2.0em;">Contact Us</h3>
    <p>Home / Support</p>
  </div>
</div>  

<div>
<!--
	<div class="container">
	<div class="col-md-6 content-pro-head content-pro-head3">
			<h2 style="font-size: 2.0em;">Get In Touch</h2><br>


		  <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
		    <span style="font-size: 18px;"> How to use a UVC Sanitizer ? </span>
		  </button>
		
		<div class="collapse" id="collapseExample">
		  <div class="card card-body">
		    <p style="font-size: 18px;color: #526467;">1.Plug in to your 230 V eletric board.<br>
			2.Press the red button to on UV sanitizer (it glows to RED).<br>
			3.Pull led of box & put what you want to sanitize.<br>
			3.touch the power button "c-" After set time (defalt time is 4 min.)<br>
			4.If you are using for medical purpose set to 8-10 min(OPTIONAL).<br>
			6.Touch the set button to start.
			7.That's it </p>
		  </div>
		</div>
		<br><br>

		<button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#collapseExample1" aria-expanded="false" aria-controls="collapseExample">
		    <span style="font-size: 18px;"> Warranty of 6 Months </span>
		  </button>
		  	<div class="collapse" id="collapseExample1">
		  <div class="card card-body">
		    <p style="font-size: 18px;color: #526467;">It has 6 months of warranty and uv lamp has 2 months of worranty
			The warranty of uv-c sanitizer is covered only in case of electronics & Electrical failure"NO PHYSICAL DAMEGE IS COVERED"</p>
		  </div>
		</div>-->
		
    </div>
	
	<div class="container">
	
            <div class="col-md-12 content-pro-head1">
  
   		                      <form action="contactprocess.php" method="post">
				                  <div class=" grid-contact">
					<div class="your-top">
						<i class="glyphicon glyphicon-user"> </i>
						<input type="text" placeholder="Name" name="name"  required >								
						<div class="clearfix"> </div>
					</div>
					<div class="your-top">
						<i class="glyphicon glyphicon-envelope"> </i>
						<input type="text" placeholder="E-mail" name="email"  required>								
						<div class="clearfix"> </div>
					</div>
					<!-- <div class="your-top">
						<i class="glyphicon glyphicon-link"> </i>
						<input type="text" placeholder="Website" name="Website"  required>								
						<div class="clearfix"> </div>
					</div> -->
					
					<textarea  placeholder=" Message" name="message"  required></textarea>
					<!-- <input type="submit"  value="Send"> -->
					<button class="btn btn-primary" type="submit" style="width: 100%; font-size: 20px;">Send</button>
				
				</div>
				<br>
				</form>
  </div>
  </div></div></div>
  <div>
  
	<div class="clearfix"> </div>
	</div>
</div>
<div class=" map">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3802.0863064598043!2d75.89788791416936!3d17.646070887924207!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc5d7657dc5ef1f%3A0x6bc6b392192f2822!2sVijapur%20Rd%2C%20Maharashtra%20413004!5e0!3m2!1sen!2sin!4v1606823233888!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>				</div>

<!--footer-->
<!--footer-->
	
	<?php require_once("footer.php"); ?>

<!--footer-->
<!-- for bootstrap working -->
	<script src="js/bootstrap.min.js"></script>
<!-- //for bootstrap working -->

</body>
</html>