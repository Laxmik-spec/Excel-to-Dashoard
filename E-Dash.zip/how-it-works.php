<!--A Design by W3layouts 
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head><meta charset="euc-kr">
<title>Edash UV Sanitizer - How It Works</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<link rel="shortcut icon" type="image/x-icon" href="images/icon.png">
<script src="js/jquery.min.js"></script>
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">


<meta name="keywords" content="Machinery Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
					jQuery(document).ready(function($) {
						$(".scroll").click(function(event){		
							event.preventDefault();
							$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
						});
					});
					</script>

<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<link href='//fonts.googleapis.com/css?family=Dosis:400,200,300,500,600,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Righteous' rel='stylesheet' type='text/css'>
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">


</head>
<body>
<!--header-->

<?php require_once("header.php"); ?>
<!---->

 <div class="jumbotron jumbotron-fluid" style="background-color: #7DD5F6;">
  <div class="container">
    <h3 style="font-size: 2.0em;">Product</h3>
    <p>Home /Product </p>
  </div>
</div> 

<div class="container">
	<!-- <h1 class="text-center">HOW IT WORKS</h1>
	<br><br> -->

	<div class="row">
		<div class="col-md-6 " style="text-align:center" >
		<img src="images/size.jpg" class="img-responsive">	
		</div>

		<div class="col-md-6 " style="text-align:center">
		<img src="images/how it works.png"class="img-responsive">	
		</div>
	
		<div class="col-md-12 text-center" >

	<!--<a href="buy-now.php" class="demo-4" style="font-size: 18px;">
   	<span id="uv-buy-btn" >
   		<p class="btn btn-primary "  id="mybtn">BUY NOW</p>
   	</span>
	</a>-->
</div>
	</div>
</div>

	<div class="container">

	<div class="row" style="padding-top: 40px;">
		<div class="col-md-4" style="">
			<img src="images/Product/tube.jpg" class="img-responsive">
		</div>
		<div class="col-md-8" style="padding-left: 25px; padding-right: 25px; padding-top: 0px; padding-bottom: 25px;">
			<p  class="para" style="font-size: 20px;text-align:justify;line-height:35px;">UV-C light has a short wavelength of 254	nanometers (nm) and is an <strong>ultraviolet light</strong> that breaks apart derm DNA, leaving it unable 
			to function or reproduce. In other words, UV-C light is germicidal (UV-A and UV-B light are not). UV-C can 
			even neutralize 'superbugs' that have developed a resistance to antibiotics.</P>
		</div>
	</div><br>

	<div class="row">
		<div class="col-md-4"  style="padding: 15px;">
			<img src="images/Product/gadget.jpg" class="img-responsive">
		</div>
		<div class="col-md-8" style="padding-left: 25px; padding-right: 25px; padding-top: 0px; padding-bottom: 25px;">
			<P  class="para" style="font-size: 20px;text-align:justify;line-height:35px;">The germs, bacteria which is a stick or stuck on the 
			surface of mobiles, electronic gadgets, masks, hand gloves & other things.
			The UV-C tube which is placed right and left of the box it spreads the UV light on the surface of the object and 
			<strong>kills the bacteria & virus.</strong></P>
		</div>
	</div><br>


	<div class="row">
		<div class="col-md-4" style="padding: 0px;">
			<img src="images/Product/360.jpg" class="text-center img-responsive">
		</div>
		<div class="col-md-8"  style="padding-left: 25px; padding-right: 25px; padding-top: 0px; padding-bottom: 25px;">
			<P  class="para" style="font-size: 20px;text-align:justify;line-height:35px;">It has a silver mirror-polished reflector with the
			help of this it spreads the light on each and every corner of the box.
			It means it <strong>sanitizes the 360° degree.</strong> So it has no shadow zone.</P>
		</div>
	</div><br>


	<div class="row">
		<div class="col-md-4" style="padding: 0px;">
			<img src="images/Product/lapi.jpg" class="img-responsive">
		</div>
		<div class="col-md-8" style="padding-left: 25px; padding-right: 25px; padding-top: 10px; padding-bottom: 25px;">
			<P class="para" style="font-size: 20px;text-align:justify;line-height:35px;"> It <strong>does not effect</strong> any electronic
			 device and other things.</P>
		</div>
	</div>
	</div>


	<div class="container" style="padding-top:40px;padding-bottom:70px">
<div class="text-center page-header" style="padding-bottom:50px;">
			<h1>What could be sanitized</h1>
				
    </div>

<div class="row">

<div class="col-md-12 content-pro-head1">
   		<div class="col-md-3 gallery-top">
			<div class="grid-ga">
			  

					<figure class="effect-img">
					<img src="images/use/vegetables.png" alt=""/>
						<figcaption><br>
							<h4>Vegetables</h4>
							
						</figcaption>	
					</figure>
					</a>
				</div>
		</div>
		<div class="col-md-3 gallery-top">
			<div class="grid-ga">
			
					<figure class="effect-img">
						<img src="images/use/food.jpg" alt=""/>
						<figcaption><br>
							<h4>Food</h4>
							
						</figcaption>			
					</figure>
					</a>
				</div>
		</div>
		<div class="col-md-3 gallery-top">
			<div class="grid-ga">
			   <!-- <a href="images/ga2.jpg" rel="title" class="b-link-stripe b-animate-go  thickbox"> -->


					<figure class="effect-img">
						<img src="images/use/electronics.jpeg" alt=""/>
						<figcaption><br>
							<h4 >Electronics</h4>
						
						</figcaption>			
					</figure>
					</a>
				</div>
		</div>
		<div class="col-md-3 gallery-top">
			<div class="grid-ga">
			   <!-- <a href="images/ga1.jpg" rel="title" class="b-link-stripe b-animate-go  thickbox">
 -->

					<figure class="effect-img">
						<img src="images/use/metal.jpg" alt=""/>
						<figcaption><br>
							<h4 >Metallic Items</h4>
						
						</figcaption>			
					</figure>
					</a>
				</div>
		</div>
</div>

<div class="col-md-12 content-pro-head1">
		<div class="col-md-3 gallery-top">
			<div class="grid-ga">
			   <!-- <a href="images/ga3.jpg" rel="title" class="b-link-stripe b-animate-go  thickbox"> -->
					<figure class="effect-img">
						<img src="images/use/toys.jpg" alt=""/>
						<figcaption><br>
							<h4 >Toys</h4>
						
						</figcaption>			
					</figure>
					</a>
				</div>
		</div>
		<div class="col-md-3 gallery-top">
			<div class="grid-ga">
			   <!-- <a href="images/ga4.jpg" rel="title" class="b-link-stripe b-animate-go  thickbox"> -->
					<figure class="effect-img">
						<img src="images/use/baby.jpg" alt=""/>
						<figcaption><br>
							<h4>Baby Products</h4>
					
						</figcaption>			
					</figure>
					</a>
				</div>
		</div>
		<div class="col-md-3 gallery-top">
			<div class="grid-ga">
			   <!-- <a href="images/ga5.jpg" rel="title" class="b-link-stripe b-animate-go  thickbox"> -->
					<figure class="effect-img">
						<img src="images/use/mask.jpg" alt=""/>
						<figcaption><br>
							<h4>Mask & Gloves</h4>
						
						</figcaption>			
					</figure>
					</a>
				</div>
		</div>
		<div class="col-md-3 gallery-top">
			<div class="grid-ga">
			   <!-- <a href="images/ga5.jpg" rel="title" class="b-link-stripe b-animate-go  thickbox"> -->
					<figure class="effect-img">
						<img src="images/use/money.jpg" alt=""/>
						<figcaption><br>
							<h4>Wallet & Money</h4>
							
						</figcaption>			
					</figure>
					</a>
				</div>
		</div>		
  </div>
</div>
</div>


<div class="container text-center">    
  <br><h1>Where Could be USED ?</h1><br><br>

<div class="row">

<div class="col-md-3">
<img class="img-responsive" src="images/app/tatoo.jpg"><br>
<h3>Tatoo Shop</h3><br>
</div>

<div class="col-md-3">
<img class="img-responsive" src="images/app/fitness.jpg"><br>
<h3>Fitness Center</h3><br>	
</div>

<div class="col-md-3">
<img class="img-responsive" src="images/app/hospital.jpeg"><br>
<h3>Hospital</h3><br>	
</div>

<div class="col-md-3">
<img class="img-responsive" src="images/app/lab.jpg"><br>	
<h3>Lab & Research center</h3><br>
</div>
</div>
  
<div class="row" style="padding-top:20px;padding-bottom:20px">

<div class="col-md-3">
<img class="img-responsive" src="images/app/hotel.jpg"><br>
<h3>Hotel</h3><br>
</div>

<div class="col-md-3">
<img class="img-responsive" src="images/app/office.jpg"><br>
<h3>Office & Building</h3><br>	
</div>

<div class="col-md-3">
<img class="img-responsive" src="images/app/college.jpg"><br>
<h3>College</h3><br>	
</div>

<div class="col-md-3">
<img class="img-responsive" src="images/app/resturant.jpg"><br>
<h3>Resturant</h3><br>	
</div>

</div>
</div>






<!--footer-->

<?php require_once("footer.php"); ?>

<!--footer-->
<!-- for bootstrap working -->
	<script src="js/bootstrap.min.js"></script>
	<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<!-- //for bootstrap working -->

</body>
</html>
<script>
  AOS.init();
</script>