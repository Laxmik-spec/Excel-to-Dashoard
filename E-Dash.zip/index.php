<!--A Design by W3layouts 
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Edash UV Sanitizer - Home</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/flexslider.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- Custom Theme files -->
<script src="js/jquery.min.js"></script>
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<link rel="shortcut icon" type="image/x-icon" href="images/icon.png">
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Machinery Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
					jQuery(document).ready(function($) {
						$(".scroll").click(function(event){		
							event.preventDefault();
							$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
						});
					});
					</script>

<link href='//fonts.googleapis.com/css?family=Dosis:400,200,300,500,600,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Righteous' rel='stylesheet' type='text/css'>
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
	<script type="text/javascript">
							$(window).load(function() {
								$("#flexiselDemo1").flexisel({
									visibleItems: 4,
									animationSpeed: 1000,
									autoPlay: true,
									autoPlaySpeed: 3000,    		
									pauseOnHover: true,
									enableResponsiveBreakpoints: true,
									responsiveBreakpoints: { 
										portrait: { 
											changePoint:480,
											visibleItems: 1
										}, 
										landscape: { 
											changePoint:640,
											visibleItems: 2
										},
										tablet: { 
											changePoint:991,
											visibleItems: 3
										}
									}
								});

								$("#flexiselDemo2").flexisel({
									visibleItems: 1,
									animationSpeed: 4000,
									autoPlay: true,
									autoPlaySpeed: 4000,    		
									pauseOnHover: true,
									enableResponsiveBreakpoints: true,
									responsiveBreakpoints: { 
										portrait: { 
											changePoint:480,
											visibleItems: 1
										}, 
										landscape: { 
											changePoint:640,
											visibleItems: 2
										},
										tablet: { 
											changePoint:991,
											visibleItems: 1
										}
									}
								});
								
							});
					</script>
		<script type="text/javascript" src="js/jquery.flexisel.js"></script>

		<style>
			#padding5
			{
				padding: 2px;
			}
			#iconSetup
			{
				border-radius: 100px;
			}
			.content-icon1 .icon:before
			{
				    content: '';
				    width: 100%;
				    height: 100%;
				    background: #000;
				    position: absolute;
				    top: 0;
				    left: 0;
				    z-index: 10;
				    -webkit-transform: scale(0);
				    -moz-transform: scale(0);
				    -ms-transform: scale(0);
				    -o-transform: scale(0);
				    transform: scale(0);
				    transition: all 0.3s ease 0s;
				    border-radius: 100px;
			}
			
			.col-md-4
			{
				padding: 25px;
			}
			.col-md-2
			{
				padding: 0px;
			}
			#paddingt10
			{
				padding-top: 10px;
			}

			.mytextSize
			{
				font-size: 20px;
				color: white;
			}

			.text-block {
				  position: absolute;
				  top: 35px;
				  left: 0px;
				 background: rgb(0, 0, 0);/* Fallback color */
		        background: rgba(0, 0, 0, 0.5);/* Black background with opacity */
		        color: #ffffff;
					padding: 10px;
					border-radius: 30px;
				}

				.text-block.mobile {
				  position: absolute;
				  top: 5px;
				  left: 0px;
				 background: rgb(0, 0, 0);/* Fallback color */
		        background: rgba(0, 0, 0, 0.5);/* Black background with opacity */
		        color: #ffffff;
					padding: 10px;
					border-radius: 30px;
					display: none;
				}
				.myTopPadding
				{
					padding-top: 160px;
				}
				#iconSize
				{
					max-width: 70%;
				}
				#bottomPadding
	{
		padding: 10px;
	}

@media only screen and (max-width: 478px) 
{
	#bottomPadding
	{
		padding-bottom: 280px;
		padding-left: 25px;
		padding-right: 25px;
	}
}
				@media screen and (max-width: 476px) {

					.text-block.mobile
					{
						display: block;
					}
					.text-block
					{
						display: none;
					}
					.topPadding
					{
						padding-top: 0px;
						margin-top: 0em;
					}
					.myTopPadding
					{
						padding-top: 0px;
					}
					#iconSize
					{
						max-width: 50%;
					}
					#bottomPadding{
						padding-bottom:50px;
					}
					@media only screen and (max-width: 478px) 
{
	#bottomPadding{
						padding-bottom:100px;
					}
				}

		</style>

</head>
<body>
<!--header-->

<?php require_once("header.php"); ?>

<!---->

<section class="slider">
           <div class="flexslider">
             <ul class="slides">
				   <li>
				   	<img src="images/slider/slider2.png" class="img-responsive" alt="">
				   </li>

				    <li>
				   	<img src="images/slider/slider1.png" class="img-responsive" alt="">
					</li>

					<li>
				   	<img src="images/slider/slider3.png" class="img-responsive" alt="">
					</li>
				  
          </ul>
        </div>
      </section>
<!--FlexSlider-->
	<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
	<script defer src="js/jquery.flexslider.js"></script>
	<script type="text/javascript">
    $(function(){
      SyntaxHighlighter.all();
    });
    $(window).load(function(){
      $('.flexslider').flexslider({
        animation: "slide",
        start: function(slider){
          $('body').removeClass('loading');
        }
      });
    });
  </script>






<!-- Changes -->
<!--  <div class="content-pro">
	<div class="container">
		<div class="row">
			<div class="col-md-12 content-pro-head content-pro-head2">
				<h3>Why Choose Us</h3>
			<p></p>	
			</div>
		</div>

    	<div>
  <div class="row">
  	<div class="col-md-1">
  		
  	</div>
  <div class="col-md-10 content-pro-head1" >
   	<ul id="flexiselDemo1">			
				<li>
					<div class="laptop">
							<div class="img-box"><img class="img-responsive zoom-img" src="images/icons/cost1.png" alt=" " /></div>
							<div class="flex-info" style="height: 280px;">
									<h4>Cost Effective</h4>
									<p style="font-size: 18px;">We keep less profitable margin on our products.
									Because our goal is to provide best cost efficient products in market to buy 
									all categories of people.</p>
							</div>
						</div>
					
				</li>
				<li>
					<div class="laptop">
							<div class="img-box"><img class="img-responsive zoom-img" src="images/icons/quality1.png" alt=" " /></div>
							<div class="flex-info flex-info2" style="height: 280px;">
									<h4>Quality</h4>
									<p style="font-size: 18px;">We never compromise with our product quality to build.</p>

							</div>
						</div>
					
				</li>
				<li>
					<div class="laptop">
							<div class="img-box"><img class="img-responsive zoom-img" src="images/icons/team1.png" alt=" " /></div>
							<div class="flex-info flex-info" style="height: 280px;">
									<h4>Team Work</h4>
									<p style="font-size: 18px;">Our team is one of the refined team to make our products 
									in timeline.</p>
							</div>
						</div>
				</li>
				<li>
					<div class="laptop">
							<div class="img-box"><img class="img-responsive zoom-img" src="images/icons/service1.png" alt=" " /></div>
							<div class="flex-info flex-info2" style="height: 280px;">
									<h4>After Market Service</h4>
									<p style="font-size: 18px;"> We provide warranty period support and after warranty as 
									well. </p>
							</div>
						</div>
				</li>
				<li>
					<div class="laptop">
							<div class="img-box"><img class="img-responsive zoom-img" src="images/icons/helping_hands1.png" alt=" " /></div>
							<div class="flex-info flex-info" style="height: 280px;">
									<h4>Helping Hand</h4>
									<p style="font-size: 18px;">We make this product to help society and community to over
									 come from this COVID-19 situation and keep less profitable margin.</p>
							</div>
						</div>
				</li>
			</ul>
		
  </div>

  <div class="col-md-1">
  		
  	</div>

  </div>
  </div>
	<div class="clearfix"> </div>
	</div>
</div>
 -->

<!-- <div>

	<div class="container">
	
	<div class="content-pro-head why-head text-center" style="padding-top: 60px;">
			<h3 style="color: #000000;">Why Choose Us</h3>
		
    </div><br>
	<div class="row">
  <div class="col-md-12 content-pro-head1">

  				<div class="col-md-4 why-text ">
					<i class="glyphicon glyphicon-usd "> </i>
					<h4 style="color: #000000;">Cost Effective</h4>
					<p style="color: #999999;font-size: 20px;">we keep less profitable margin on our products.Because our goal is to provide best cost efficient products in market to buy all categories of people.</p>
				</div>
   				
				
				<div class="col-md-4 why-text ">
					<i class="glyphicon glyphicon-ok"> </i>
					<h4 style="color: #000000;">Quality</h4>
					<p style="color: #999999;font-size: 20px;">we never compromise with our product quality to build.</p>
				</div>
				<div class="col-md-4 why-text ">
					<i class="glyphicon glyphicon-user"> </i>
					<h4 style="color: #000000;">Team Work</h4>
					<p style="color: #999999;font-size: 20px;">Our team is one of the refined team to make our products in timeline.</p>
				</div>

				

				
		<div class="clearfix"> </div>
  </div>

	<div class="clearfix"> </div>
	</div>
	<div class="row">
		<div class="col-md-12 text-center">
			<div class="col-md-2">
				
			</div>
			<div class="col-md-4 why-text ">
					<i class="glyphicon glyphicon-flag"> </i>
					<h4 style="color: #000000;">After Market Service</h4>
					<p style="color: #999999;font-size: 20px;">we provide warranty period support and after warranty as well.</p>
				</div>

				

				<div class="col-md-4 why-text ">
					<i class="glyphicon glyphicon-thumbs-up "> </i>
					<h4 style="color: #000000;">Helping Hand</h4>
					<p style="color: #999999;font-size: 20px;">We make this product to help society and community to over come from this COVID-19 situation.And keep less profitable margin.</p>
				</div>
				<div class="col-md-2">
				
			</div>
		</div>
	</div>
</div>
</div> -->



<!--content-->
<div class="about">
	<div class="container">
		<div class="row">

		<div class="col-md-6">
		
				<h2>Edash UV Sanitizer</h2><br>
				<p class="para" style="text-align:justify;font-size: 20px;line-height:35px;">Introducing <strong>Edash UV-C Sanitizer
				</strong>, a box-shaped sanitation chamber that uses shot-wavelength UV-C (ultra-violet C) rays 
				to kill 99.99%* viruses including coronavirus, bacteria & fungi from the surface of all inanimate 
				objects exposed to it, like watches, wallets, shoes, mobile phone, keys, cash, mask, vegetables, 
				etc. in just 4 minutes (for commercial use in home & offices) and 8-10 minutes (for hospital and 
				medical equipment).</p><br>

				
			
		</div>

		<div class="col-md-6 text-center" >
			<img src="images/product-new1.png" class="img-responsive">

			
   	<span>
   		<p class="btn btn-primary btn-lg " > At ₹3,999</p>
   	</span>

		</div>
	
	</div>
	</div>
</div>


	<div class="container" style="padding-bottom:100px">
	<div class="text-center content-pro-head content-pro-head2" style="padding-bottom:50px">
			<h1>Why choose us</h1>
			<!-- <p>Many desktop publishing packages and web page editors now use Lorem Ipsum  Ipsum as their default model text now use Lorem Ipsum as their default model text, packages and web page editors now use Lorem Ipsum now use Lorem Ipsum as their default model text, and a as their default model text, lorem ipsum' will uncover many</p> -->
		
    </div>
	
	<div class="row">
    		    		

			  <div class="col-md-12 content-pro-head1" >
			   	<ul id="flexiselDemo1">			

							<li>
								<div class="laptop" style="padding: 10px;">
										<div class="img-box" style="padding-bottom:20px">
											<img src="images/icons/quality.png" alt=" " >
										</div>
										<div class="flex-info flex-info2" style="height:230px; background-color: #32BCF1;">
												<h3 style="color:#fff">Quality<br><br></h3>
												<p style="text-align:justfy">We never compromise with our product quality 
												to build.</p>

										</div>
									</div>
							</li>

							<li>
								<div class="laptop" style="padding: 10px;" >
										<div class="img-box" style="padding-bottom:20px">
										<img src="images/icons/cost.png" alt=" "  />
									</div>
										<div class="flex-info" style="height:230px; background-color: #00ADEE;">
										<h3 style="color:#fff">Cost<br> Effective</h3>
												<p style="text-align:justify">We keep less profitable margin on our products.
												Because our goal is to provide best cost efficient products in market to buy 
												all categories of people.</p>
										</div>
								</div>
							</li>

							<li>
								<div class="laptop" style="padding: 10px;">
										<div class="img-box" style="padding-bottom:20px">
											<img src="images/icons/team.png" alt=" " />
										</div>
										<div class="flex-info flex-info" style="height: 230px;background-color: #00ADEE;">
										<h3 style="color:#fff">Team<br> Work</h3>
												<p style="text-align:justify">Our team is one of the refined team to make our products
												 in timeline.</p>
										</div>
									</div>
							</li>
							<li>
								<div class="laptop" style="padding: 10px;">
										<div class="img-box" style="padding-bottom:20px">
											<img src="images/icons/helping_hands.png" alt=" " />
										</div>
										<div class="flex-info flex-info" style="height: 230px; background-color: #00ADEE;">
										<h3 style="color:#fff">Helping<br>Hand</h3>
												<p style="text-align:justify">We make this product to help society and community to 
												over come from this COVID-19 situation and keep less profitable margin.</p>
										</div>
									</div>
							</li>
							<li>
								<div class="laptop" style="padding: 10px;">
										<div class="img-box" style="padding-bottom:20px">
											<img src="images/icons/service.png" alt=" " />
										</div>
										<div class="flex-info flex-info2" style="height: 230px; background-color: #32BCF1;">
										<h3 style="color:#fff">After <br>Market Service</h3>
												<p style="text-align:justify"> We provide warranty period support and after warranty 
												as well. </p>
										</div>
									</div>
							</li>
							
						</ul>	
			  </div>
 	 </div>
</div>
</div>





<!-- Why Choose Us -->
<!--  <div>
	<div class="container" style="padding-top: 40px;" >
		<div class="col-md-4 content-pro-head content-pro-head2">
			<h3 class="text-center">Why Choose Us</h3>
			<p></p>
    	</div>
  <div class="col-md-8 content-pro-head1" >
   	<ul id="flexiselDemo1">			
				<li>
					<div class="laptop" style="padding: 10px;" >
							<div class="img-box"><img style="max-width: 70%;" src="images/icons/cost1.png" alt=" "  /></div>
							<div class="flex-info" style="height: 280px; background-color: #228DDD;">
									<h4>Cost Effective</h4>
									<p style="font-size: 18px;">we keep less profitable margin on our products.Because 
									our goal is to provide best cost efficient products in market to buy all categories 
									of people.</p>
							</div>
						</div>
					
				</li>
				<li>
					<div class="laptop" style="padding: 10px;">
							<div class="img-box"><img style="max-width: 70%;" src="images/icons/quality1.png" alt=" " /></div>
							<div class="flex-info flex-info2" style="height: 280px; background-color: #78BAEA;">
									<h4>Quality</h4>
									<p style="font-size: 18px;">we never compromise with our product quality to build.</p>

							</div>
						</div>
					
				</li>
				<li>
					<div class="laptop" style="padding: 10px;">
							<div class="img-box"><img style="max-width: 70%;" src="images/icons/team1.png" alt=" " /></div>
							<div class="flex-info flex-info" style="height: 280px; background-color: #228DDD;">
									<h4>Team Work</h4>
									<p style="font-size: 18px;">Our team is one of the refined team to make our products in timeline.</p>
							</div>
						</div>
				</li>
				<li>
					<div class="laptop" style="padding: 10px;">
							<div class="img-box"><img style="max-width: 70%;" src="images/icons/service1.png" alt=" " /></div>
							<div class="flex-info flex-info2" style="height: 280px; background-color: #78BAEA;">
									<h4>After Market Service</h4>
									<p style="font-size: 18px;"> we provide warranty period support and after warranty as well. </p>
							</div>
						</div>
				</li>
				<li>
					<div class="laptop" style="padding: 10px;">
							<div class="img-box"><img style="max-width: 70%;" src="images/icons/helping_hands1.png" alt=" " /></div>
							<div class="flex-info flex-info" style="height: 280px; background-color: #228DDD;">
									<h4>Helping Hand</h4>
									<p style="font-size: 18px;">We make this product to help society and community to over come from this COVID-19 situation.And keep less profitable margin.</p>
							</div>
						</div>
				</li>
			</ul>
		
  </div>
	<div class="clearfix"> </div>
	</div>
</div> -->




<div class="container" id="bottomPadding">
<div class="text-center content-pro-head content-pro-head2" style="padding-bottom:50px">
			<h1>How It Works</h1>
			<!-- <p>Many desktop publishing packages and web page editors now use Lorem Ipsum  Ipsum as their 
			default model text now use Lorem Ipsum as their default model text, packages and web page editors 
			now use Lorem Ipsum now use Lorem Ipsum as their default model text, and a as their default model 
			text, lorem ipsum' will uncover many</p> -->
		
    </div>
<div class="row">

<div class="col-md-6"  >
			<img src="images/how it works.png" class="img-responsive">
		</div>

<div class="col-md-6">

<p style="font-size:20px;line-height:35px;text-align:justify;"> UV-C light has a short wavelength of 254 nanometers (nm) and is an ultraviolet 
light that breaks apart derm DNA, leaving it unable to function or reproduce.  In other words, UV-C light is germicidal (UV-A and UV-B light are not). UV-C can even neutralize 'superbugs' that have developed a resistance to antibiotics.



 <br></p>
<a href="how-it-works.php" class="demo-4" style="font-size: 18px;">
   	<span id="uv-buy-btn">
   		<p class="btn btn-primary" id="mybtn">VIEW MORE</p>
   	</span>
    </a>
</div>
</div>
</div>










<div class="container"  style="padding-top:40px;padding-bottom:70px">
<div class="text-center page-header" style="padding-bottom:50px;">
			<h1>What could be sanitized</h1>
				
    </div>

<div class="row">

<div class="col-md-12 content-pro-head1">
   		<div class="col-md-3 gallery-top">
			<div class="grid-ga">
			  

					<figure class="effect-img">
					<img src="images/use/vegetables.png" alt=""/>
						<figcaption><br>
							<h4>Vegetables</h4>
							
						</figcaption>	
					</figure>
					</a>
				</div>
		</div>
		<div class="col-md-3 gallery-top">
			<div class="grid-ga">
			
					<figure class="effect-img">
						<img src="images/use/food.jpg" alt=""/>
						<figcaption><br>
							<h4>Food</h4>
							
						</figcaption>			
					</figure>
					</a>
				</div>
		</div>
		<div class="col-md-3 gallery-top">
			<div class="grid-ga">
			   <a href="images/ga2.jpg" rel="title" class="b-link-stripe b-animate-go  thickbox">


					<figure class="effect-img">
						<img src="images/use/electronics.jpeg" alt=""/>
						<figcaption><br>
							<h4 >Electronics</h4>
						
						</figcaption>			
					</figure>
					</a>
				</div>
		</div>
		<div class="col-md-3 gallery-top">
			<div class="grid-ga">
			   <a href="images/ga1.jpg" rel="title" class="b-link-stripe b-animate-go  thickbox">


					<figure class="effect-img">
						<img src="images/use/metal.jpg" alt=""/>
						<figcaption><br>
							<h4 >Metallic Items</h4>
						
						</figcaption>			
					</figure>
					</a>
				</div>
		</div>
</div>

<div class="col-md-12 content-pro-head1">
		<div class="col-md-3 gallery-top">
			<div class="grid-ga">
			   <a href="images/ga3.jpg" rel="title" class="b-link-stripe b-animate-go  thickbox">
					<figure class="effect-img">
						<img src="images/use/toys.jpg" alt=""/>
						<figcaption><br>
							<h4 >Toys</h4>
						
						</figcaption>			
					</figure>
					</a>
				</div>
		</div>
		<div class="col-md-3 gallery-top">
			<div class="grid-ga">
			   <a href="images/ga4.jpg" rel="title" class="b-link-stripe b-animate-go  thickbox">
					<figure class="effect-img">
						<img src="images/use/baby.jpg" alt=""/>
						<figcaption><br>
							<h4>Baby Products</h4>
					
						</figcaption>			
					</figure>
					</a>
				</div>
		</div>
		<div class="col-md-3 gallery-top">
			<div class="grid-ga">
			   <a href="images/ga5.jpg" rel="title" class="b-link-stripe b-animate-go  thickbox">
					<figure class="effect-img">
						<img src="images/use/mask.jpg" alt=""/>
						<figcaption><br>
							<h4>Mask & Gloves</h4>
						
						</figcaption>			
					</figure>
					</a>
				</div>
		</div>
		<div class="col-md-3 gallery-top">
			<div class="grid-ga">
			   <a href="images/ga5.jpg" rel="title" class="b-link-stripe b-animate-go  thickbox">
					<figure class="effect-img">
						<img src="images/use/money.jpg" alt=""/>
						<figcaption><br>
							<h4>Wallet & Money</h4>
							
						</figcaption>			
					</figure>
					</a>
				</div>
		</div>		
  </div>
</div>
	

<div class="page-header">
        <h1>Product Specifications</h1>
      </div>
  
  <table style="height: 593px; width: 100%; border-collapse: collapse; border-style: solid; border-color: grey; background-color: blue; margin-left: auto; margin-right: auto;" border="1">
<tbody>
<tr style="height: 53px;">
<td style="width: 50%; height: 53px; background-color: #050a30;">
<h3 style="text-align: center;"><span style="color: #ffffff;">Product Specification</span></h3>
</td>
<td style="width: 50%; height: 53px; background-color: #050a30; text-align: left;">
<h3 style="text-align: center;"><span style="color: #ffffff;">Edash UV sanitizer</span></h3>
</td>
</tr>
<tr style="height: 54px; text-align: left;">
<td style="width: 50%; height: 54px; background-color: #050a30;">
<h4 style="padding-left: 40px;"><span style="color: #ffffff;">Capacity</span></h4>
</td>
<td style="width: 50%; height: 54px; background-color: white; text-align: center;">
<h4>34 Liter</h4>
</td>
</tr>
<tr style="height: 54px; text-align: left;">
<td style="width: 50%; height: 54px; background-color: #050a30;">
<h4 style="padding-left: 40px;"><span style="color: #ffffff;">Power Consumption</span></h4>
</td>
<td style="width: 50%; height: 54px; background-color: white; text-align: center;">
<h4>22 W</h4>
</td>
</tr>
<tr style="height: 54px; text-align: left;">
<td style="width: 50%; height: 54px; background-color: #050a30;">
<h4 style="padding-left: 40px;"><span style="color: #ffffff;">Outer Dimensions(L x W x H)</span></h4>
</td>
<td style="width: 50%; background-color: white; height: 54px; text-align: center;">
<h4>50x30x30 cm</h4>
</td>
</tr>
<tr style="height: 54px; text-align: left;">
<td style="width: 50%; height: 54px; background-color: #050a30;">
<h4 style="padding-left: 40px;"><span style="color: #ffffff;">Inner Dimensions(L x W x H)</span></h4>
</td>
<td style="width: 50%; background-color: white; height: 54px; text-align: center;">
<h4>40x29x29 cm</h4>
</td>
</tr>
<tr style="height: 54px; text-align: left;">
<td style="width: 50%; height: 54px; background-color: #050a30;">
<h4 style="padding-left: 40px;"><span style="color: #ffffff;">Inner construction</span></h4>
</td>
<td style="width: 50%; height: 54px; background-color: white; text-align: center;">
<h4>Mirror finish stainless steel</h4>
</td>
</tr>
<tr style="height: 54px; text-align: left;">
<td style="width: 50%; height: 54px; background-color: #050a30;">
<h4 style="padding-left: 40px;"><span style="color: #ffffff;">Outer construction</span></h4>
</td>
<td style="width: 50%; height: 54px; background-color: white; text-align: center;">
<h4>Powder Coated CRCA</h4>
</td>
</tr>
<tr style="height: 54px; text-align: left;">
<td style="width: 50%; height: 54px; background-color: #050a30;">
<h4 style="padding-left: 40px;"><span style="color: #ffffff;">Electrical supply required</span></h4>
</td>
<td style="width: 50%; height: 54px; background-color: white; text-align: center;">
<h4>1ph,220-240v,50Hz</h4>
</td>
</tr>
<tr style="height: 54px; text-align: left;">
<td style="width: 50%; height: 54px; background-color: #050a30;">
<h4 style="padding-left: 40px;"><span style="color: #ffffff;">No. of uv-c lamps</span></h4>
</td>
<td style="width: 50%; height: 54px; background-color: white; text-align: center;">
<h4>2 no.</h4>
</td>
</tr>
<tr style="height: 54px; text-align: left;">
<td style="width: 50%; height: 54px; background-color: #050a30;">
<h4 style="padding-left: 40px;"><span style="color: #ffffff;">Life of uv-c lamp</span></h4>
</td>
<td style="width: 50%; height: 54px; background-color: white; text-align: center;">
<h4>11000 hours</h4>
</td>
</tr>
<tr style="height: 54px; text-align: left;">
<td style="width: 50%; height: 54px; background-color: #050a30;">
<h4 style="padding-left: 40px;"><span style="color: #ffffff;">Recommended Disinfecting Cycle</span></h4>
</td>
<td style="width: 50%; height: 54px; background-color: white; text-align: center;">
<h4>1-10 mins. Varys as per application</h4>
</td>
</tr>
</tbody>
</table>
  </div>








	<div class="container" style="padding-top: 50px;">
		<!-- <div class="row">
			<div class="col-md-12 content-pro-head content-pro-head2">
				<h1>Testimonial</h1>
				
	    	</div>
    	</div> -->
    	<div class="row">
    		<h3 class="text-center" style="font-size: 2.0em; color: black;">Testimonials</h3>
    		<div class="col-md-1">
    			
    		</div>
			  <div class="col-md-10 content-pro-head1" style="padding: 10px;">
			   	<ul id="flexiselDemo2">			

							<li>
								<div class="laptop" style="padding: 10px;">
										<div class="flex-info flex-info2" style="background-color: transparent;">
											<div class="row">

												<div class="col-md-12">
											<div class="col-md-12">
														
<img src="images/user1.png" alt="Avatar">
												<p style="font-size: 20px;text-align:justify; color: #526467;">I have 2 restaurants S’n’S 
												& Oviya. I use Edash UV C sanitizer for to sanitise multiple things like 
												menu card ,tissue papers, masks,cash,also my staff is also use for 
												sanitize their personal things as well.I like it</p>	
												<p style="font-size: 20px; color: #526467;"> <b>- Amol Lavte (sugar’n’spice ,Oviya restaurants owner) </b></p>
													</div>
												</div>
											</div>

										</div>
									</div>		
						</li>

							<li>
								<div class="laptop" style="padding: 10px;">
										<div class="flex-info flex-info2" style="background-color: transparent;">
											<div class="row">

												<div class="col-md-12">
													<div class="col-md-12">
													<img src="images/user1.png" alt="Avatar">
												<p style="font-size: 20px;text-align:justify; color: #526467;">I am use Edash uvc sanitizer 
												for sanitize cash , electronic gadgets , wallet and many more as well.</p>	
												<p style="font-size: 20px; color: #526467;"> <b>- Adwet(Anna idli Solapur staff in-charge) </b></p>
													</div>
												</div>
											</div>

										</div>
									</div>
								
						</li>

						<li>
								<div class="laptop" style="padding: 10px;">
										<div class="flex-info flex-info2" style="background-color: transparent;">
											<div class="row">

												<div class="col-md-12">
													<div class="col-md-12">
													<img src="images/user2.png" alt="Avatar">	
												<p style="font-size: 20px;text-align:justify; color: #526467;">As doctor I know how the 
												cleaning is very important Edash UV C sanitizer help me a lot to sanitise
												my day today medical equipment like stethoscope, B.P. & sugar machine, 
												phone and so on. This machine does all work without hassle.</p>	
												<p style="font-size: 20px; color: #526467;"> <b>- Dr.Lavte Madam</p>
													</b></div>
												</div>
											</div>

										</div>
									</div>
								
						</li>

				

						</ul>
					
			  </div>
		
 	 </div>
	<div class="clearfix"> </div>
	</div>
</div>

<!--  <div class="content-pro p-1">
 	<div class="container" style="position: relative;">
 		<div class="row">
 			<div class="col-md-12" data-aos="flip-up" data-aos-easing="ease-in-back" data-aos-delay="1300" data-aos-duration="1500">

			 <img src="images/all/edash-1.png" class="img-responsive">
			
			 <div class="col-md-6" data-aos="flip-left" data-aos-easing="ease-in-back" data-aos-delay="1400" data-aos-duration="1500">
			 <img src="images/all/img-1.png" class="img-responsive p-0">
			</div>

			<div class="col-md-6" data-aos="flip-right" data-aos-easing="ease-in-back" data-aos-delay="1400" data-aos-duration="1500">
			<img src="images/all/360-img.png" class="img-responsive">
			</div>
			


			</div>

			<div class="col-md-12 p-0" data-aos="fade-down" data-aos-easing="ease-in-back" data-aos-delay="1600" data-aos-duration="1500">
			 <img src="images/all/img-2.png" class="img-responsive">
			
			</div>

 			</div>
 		</div>
 	</div> -->



 <!-- <div class="content-pro">
	<div class="container">
		<div class="col-md-4 content-pro-head content-pro-head2">
			<h3>MINIMAL & Simple Design</h3>
    </div>
  <div class="col-md-8 content-pro-head1">
   	<ul id="flexiselDemo2">			
				<li id="padding5">
					<div class="laptop" style="border:2px solid #d2a775;">
							<div class="img-box"><img class="img-responsive zoom-img" src="images/all/switch.png" alt=" " /></div>
							<div class="flex-info flex-info2">
									<h3 id="mytextSize">ON / OFF Switch <br><br><br><br></h3>
							</div>
						</div>
					
				</li>
				<li id="padding5" >
					<div class="laptop" style="border:2px solid #d2a775;">
							<div class="img-box"><img class="img-responsive zoom-img" src="images/all/timer.png" alt=" " /></div>
							<div class="flex-info flex-info1">
									<h3>A timer to set run time for sanitation <br><br></h3>
							</div>
						</div>
					
				</li>
				<li id="padding5">
					<div class="laptop" style="border:2px solid #d2a775;">
							<div class="img-box"><img class="img-responsive zoom-img" src="images/all/big_space.png" alt=" " /></div>
							<div class="flex-info flex-info2">
									<h3> Big in space more sanitized <br><br><br></h3>
							</div>
						</div>
				</li>
				<li id="padding5">
					<div class="laptop" style="border:2px solid #d2a775;">
							<div class="img-box"><img class="img-responsive zoom-img" src="images/all/box.png" alt=" " /></div>
							<div class="flex-info flex-info1">
									<h3> silver-coated reflectors for 360° degree sanitization</h3>
							</div>
						</div>
				</li>
			</ul>
		
  </div>
	<div class="clearfix"> </div>
	</div>
</div> -->


<!---->
<!-- <div class="content-grid">
	<div class="container" style="padding-top: 40px;">
		<h1 class="text-center">Features</h1>
		<div class="row" >
		<div class="col-md-4 content-icon1" data-aos="fade-down"
     data-aos-anchor-placement="center-center" data-aos-delay="500" data-aos-duration="500" data-aos-easing="ease-in-out">
			<div class="text-center">
				<i class="fa fa-clock-o" aria-hidden="true" style="font-size: 50px;"></i>
			</div>
			<h3 class="text-center" id="paddingt10">BUILD IN TIMER</h3>
			<p class="text-center mytextSize">Digital timer to set and reset  time to sanitizes stuffs & built in buzzer</p>
		</div>

		<div class="col-md-4 content-icon1" data-aos="fade-down" data-aos-delay="800" data-aos-duration="500">
			<div class="text-center">
				<i class="fa fa-battery-full" aria-hidden="true" style="font-size: 50px;"></i>
			</div>
			<h3 class="text-center" id="paddingt10">ENERGY EFFICIENT</h3>
			<p class="text-center mytextSize">It has 2 UV lamp that consumes only 25W</p>
		</div>
		<div class="col-md-4 content-icon1" data-aos="fade-down" data-aos-delay="1200" data-aos-duration="500">
			<div class="text-center">
				<i class="fa fa-thumbs-o-up" aria-hidden="true" style="font-size: 50px;"></i>
			</div>
			<h3 class="text-center" id="paddingt10">SOLID BUILD QUALITY</h3>
			<p class="text-center mytextSize">We use good metal quality and coat with anti rust coating</p>
		</div>
		<div class="col-md-4 content-icon1" data-aos="fade-down" data-aos-delay="1500" data-aos-duration="500">

			<div class="text-center">
				<i class="fa fa-cog" aria-hidden="true" style="font-size: 50px;"></i>
			</div>
			<h3 class="text-center" id="paddingt10">SIMPLE SETUP</h3>
			<p class="text-center mytextSize">Just press on button & set timer as per your requirement and go.</p>
		</div>
			<div class="col-md-4 content-icon1" data-aos="fade-down" data-aos-delay="1800" data-aos-duration="500">

			<div class="text-center">
				<i class="fa fa-cube" aria-hidden="true" style="font-size: 50px;"></i>
			</div>
			<h3 class="text-center" id="paddingt10">LARGE IN SPACE</h3>
			<p class="text-center mytextSize">It is large in space.You can put multiple things in it </p>
		</div>
		<div class="col-md-4 content-icon1" data-aos="fade-down" data-aos-delay="2200" data-aos-duration="500">
			<div class="text-center">
				<i class="fa fa-code-fork" aria-hidden="true" style="font-size: 50px;"></i>
			</div>
			<h3 class="text-center" id="paddingt10">USED FOR MEDICAL FIELD</h3>
			<p class="text-center mytextSize">This sanitizer is also used for medical purpose as well(Just set time to 8-10 min.)</p>
		</div>
		</div>

		<div class="clearfix"> </div>
	</div>
 </div> -->
 <!---->


<!--  <div class="content-pro content-pro1">
	<div class="container">
	<div class="col-md-4 content-pro-head team-t">
			<h3>Our Team</h3>
			<p>Many desktop publishing packages and web page editors now use Lorem Ipsum  Ipsum as their default model text now use Lorem Ipsum as their default model text, packages and web page editors now use Lorem Ipsum now use Lorem Ipsum as their default model text, and a as their default model text, lorem ipsum' will uncover many</p>
		
    </div>
  <div class="col-md-8 content-pro-head1 team-t1">
   	<div class="col-md-4 bottom-grid ">
			<div class="btm-right">
				<img src="images/te.jpg" class="img-responsive" alt=" ">
					<div class="captn">						
							<h4>Victoria</h4>
							<p>Ceo</p>
						<ul class="social-ic">
			<li><a href="#"><i></i></a></li>
			<li><a href="#"><i class="ic"></i></a></li>
			<li><a href="#"><i class="ic1"></i></a></li>
			<li><a href="#"><i class="ic2"></i></a></li>
		</ul>
					</div>
			</div>
		</div>
		<div class="col-md-4 bottom-grid ">
			<div class="btm-right">
				<img src="images/te1.jpg" class="img-responsive" alt=" ">
					<div class="captn">
					
							<h4>Adley</h4>
						<p>Manager</p>
						<ul class="social-ic">
			<li><a href="#"><i></i></a></li>
			<li><a href="#"><i class="ic"></i></a></li>
			<li><a href="#"><i class="ic1"></i></a></li>
			<li><a href="#"><i class="ic2"></i></a></li>
		</ul>
					</div>
			</div>
		</div>
		<div class="col-md-4 bottom-grid ">
			<div class="btm-right">
				<img src="images/te2.jpg" class="img-responsive" alt=" ">
					<div class="captn">
						
							<h4>Immortal</h4>
						<p>Engineer</p>
						<ul class="social-ic">
			<li><a href="#"><i></i></a></li>
			<li><a href="#"><i class="ic"></i></a></li>
			<li><a href="#"><i class="ic1"></i></a></li>
			<li><a href="#"><i class="ic2"></i></a></li>
		</ul>
					</div>
			</div>
		</div>

  </div>
  
	<div class="clearfix"> </div>
	</div>
</div> -->
<!--//-->


<!--footer-->
<!-- <p align="center"><a href="info.pdf" class="btn btn-primary" style="font-size: 18px;">Information Broucher </a></p><br> -->

<?php require_once("footer.php"); ?>
<!--footer-->
<!-- for bootstrap working -->
	<script src="js/bootstrap.min.js"></script>
	<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<!-- //for bootstrap working -->

</body>
</html>
<script>
  AOS.init();
</script>