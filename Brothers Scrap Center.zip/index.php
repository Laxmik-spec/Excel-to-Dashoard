<!DOCTYPE html>
<html lang="en">
   <!-- Basic -->
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <!-- Mobile Metas -->
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta name="viewport" content="initial-scale=1, maximum-scale=1">
   <!-- Site Metas -->
   <title>Brother's Scrap Center</title>
   <meta name="keywords" content="Brother's scarp center, Scrap dealer, Scrap dealer in solapur, Scrap Dealer in Maharashtra,
   Buy and sell all type of scrap, Recycling of scrap, Composition Dealer, Scrap near me, Scrap dealer pune, 
   Scrap shop, Metal Scrap in solapur, Scrap buyers in solapur, Battery Scrap, Plastic Scrap, Best Scrap Dealer in solapur,
   Car Scrap, Steel scrap">

   <meta name="description" content="Scrap Dealer | Brother's scarp center | All India scrap Buy and sell | 
   Best Scrap dealer in solapur We are the best Scrap dealers all over India dealing since last 15 years. 
   We buy and sell all types of Scrap which includes metal, plastic batteries and  hospital scrap etc.">
   <meta name="author" content="">
   <!-- Site Icons -->
   <link rel="shortcut icon" href="images/logo.png" type="image/x-icon" />
   <!-- Bootstrap CSS -->
   <link rel="stylesheet" href="css/bootstrap.min.css">
   <!-- Site CSS -->
   <link rel="stylesheet" href="style.css">
   <!-- Colors CSS -->
   <link rel="stylesheet" href="css/colors.css">
   <!-- ALL VERSION CSS -->
   <link rel="stylesheet" href="css/versions.css">
   <!-- Responsive CSS -->
   <link rel="stylesheet" href="css/responsive.css">
   <!-- building CSS -->
   <link rel="stylesheet" href="css/building.css">

   <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"> -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script> -->
  <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> -->


<style>

.size{

font-size:40px;
}

.border {
    display: inline-block;
    width: 70px;
    height: 70px;
    margin: 6px;
  }

  #margin{
     margin-top:50px;
  }


  @media (min-width: 768px) {
#margin
{
   margin-top:50px;
}
.size
{
font-size:10px;
}
  }
@media (min-width: 320px) 
{
#margin
{
   margin-top:60px;
}
.size{

font-size:5px;
}
  }

  @media (min-width: 568px) 
{
#margin
{
   margin-top:60px;
}
.size{

font-size:5px;
}
  }
</style>
   <!-- <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"> -->
<!-- <link rel="stylesheet" type="text/css" href="https://pixinvent.com/stack-responsive-bootstrap-4-admin-template/app-assets/css/bootstrap-extended.min.css"> -->
<!-- <link rel="stylesheet" type="text/css" href="https://pixinvent.com/stack-responsive-bootstrap-4-admin-template/app-assets/fonts/simple-line-icons/style.min.css"> -->
<!-- <link rel="stylesheet" type="text/css" href="https://pixinvent.com/stack-responsive-bootstrap-4-admin-template/app-assets/css/colors.min.css"> -->
<!-- <link rel="stylesheet" type="text/css" href="https://pixinvent.com/stack-responsive-bootstrap-4-admin-template/app-assets/css/bootstrap.min.css"> -->


   </head>
   <body class="building_version" data-spy="scroll" data-target=".header">
      <!-- LOADER -->
      <div id="preloader">
         <img class="preloader" src="images/loaders/loader-building2.gif" alt="">
      </div>
      <!-- end loader -->
      <!-- END LOADER -->
      <header class="header header_style_01">
         <nav class="megamenu navbar navbar-default" data-spy="affix">
            <!-- <div class="top-header">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12 col-md-12 col-sm-12 col-xs-hidden">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-hidden">
                           <div class="gem-contacts-item gem-contacts-phone">
                              <a class="phone-icon" href="#" target="_blank" title="phone"><i class="fa fa-phone" aria-hidden="true"></i>+91 8698719777</a>
                           </div>
                        </div>
                        <div class="top-area-block top-area-socials socials-colored-hover">
                           <div class="socials inline-inside"> 
                              <a class="socials-item" href="#" target="_blank" title="facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                              <a class="socials-item" href="#" target="_blank" title="linkedin"><i class="fa fa-linkedin" aria-hidden="true"></i></a> 
                              <a class="socials-item" href="#" target="_blank" title="twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a> 
                              <a class="socials-item" href="#" target="_blank" title="instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a> 
                              <a class="socials-item" href="#" target="_blank" title="pinterest"><i class="fa fa-pinterest" aria-hidden="true"></i></a> 
                              <a class="socials-item" href="#" target="_blank" title="youtube"><i class="fa fa-youtube" aria-hidden="true"></i></a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div> -->
            <div class="container" max-width:100%>
               <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                  <span class="sr-only">Toggle navigation</span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand " href="index.php"><img src="images/logo.png" alt="image"><span>Brother's Scrap Center</span></a>
               </div>
               <div id="navbar" class="navbar-collapse collapse">
                  <ul class="nav navbar-nav navbar-right">
                     <li ><a data-scroll href="#home">Home</a></li>
                     <li><a data-scroll href="#about">About Us </a></li>
                     <li><a data-scroll href="#products">Dealings</a></li>
                     <li><a data-scroll href="#services">Our Work</a></li>
                     <li><a data-scroll href="#owner">Management </a></li>
                     <li><a data-scroll href="#gallery">Gallery</a></li>
                     <li><a data-scroll href="#price">Contact Us</a></li>
                  </ul>
               </div>
            </div>
         </nav>
      </header>
      <div id="home" class="parallax first-section" data-stellar-background-ratio="0.5" style="background-image:url('images/icons/7.jpg');">
         <div class="container">
            <div class="row">
               <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-md-offset-2 text-center">
                  <div class="big-tagline">
                     <img class="border-line-img" src="images/sep-line-white.png" alt="" />
                     <h2><span class="yellow">Brother's Scrap Center</span></h2>
                     <img class="border-line-img" src="images/sep-line-white.png" alt="" />
                     <img style="margin-bottom:40px;" class="border-line-img" src="images/logo.jpg" alt="" />
                    <p class="lead">Buy & sale all types of scrap<br>( Retail, Wholesale & Government contracts )</p>
                     <!-- <a data-scroll href="#products" class="btn btn-light btn-radius btn-brd">View all Products</a> -->
                  </div>
               </div>
            </div>
            <!-- end row -->
         </div>
         <!-- end container -->
      </div>
      <!-- end section -->
      <div id="about" class="section wb">
         <div class="container">
            <div class="message-box ">
               <h2>About Us</h2>
               </div>
            <div class="row">
              
           <div class="col-md-4 text-center">
            
            <img src="images/products/about.jpeg" class="float-left "style="border-radius:10px">

           </div>

           <div class="col-md-8">

            <div class="message-box">
               <p class="lead" style="color:darkslategray;text-align:justify;font-weight:bold">The <strong>" Brother's Scrap Center "</strong>  has been 

                  running since 10 years but between couple of years it gain momentum & owner officially inaugurated
                  this firm in 2017-18 for the online and offline scrap dealing.<br><br>

Scrap business is considered as offline busines & still many dealers
only deal in offline market that is why <strong>Brother's Scarp Center</strong> was
started in online as well as offline for more convenient scrap dealing.
</p>
               <!-- <a href="#" class="read-more">Read More</a> -->
            </div>
         </div>
            </div>
            <!-- end row -->
            <div class="row text-center about-row">
               <div class="col-md-4 col-sm-12 col-xs-12">
                  <div class="row">
                     <div class="service-widget">

                        <img src="images/icons/eye.png" align="center" alt="" class="text-center img-fluid ">
<br><br>
                        <h1><strong>Vision</strong></h1>
                        <p class="lead" style="font-size:18px;text-align:left;color:darkslategray;font-weight:bold">
                           Scrap metal services, LLC specializes in scrap processing, management, brokerage & steel
                            mill services to ferrous & non-ferrous suppliers & consumers emphasizing customer 
                            service & integrity.<br><br><br></p>
                     </div>
                     <!-- end service -->
                  </div>
               </div>
               <div class="col-md-4 col-sm-12 col-xs-12">
                  <div class="row">
                     <div class="service-widget">
               
                           
                        <img src="images/icons/value.png" align="center" alt="" class="text-center img-fluid ">
                        <br><br>
                       
                        <h1><strong>Values</strong> </h1>
                        <p class="lead" style="font-size:18px;text-align:left;color:darkslategray;font-weight:bold">
                           Values are the gateway to trust, which we call the most valuable asset. Saftey of work has been taken care seriously & given first priority.
                            We value integrity & hold ourselves accountable to
                           meet our customer agreements & deadlines.We strive for excellence, delivering 
                           high-quality service & products.</p>
                     </div>
                     <!-- end service -->
                  </div>
               </div>
               <div class="col-md-4 col-sm-12 col-xs-12">
                  <div class="row">
                     <div class="service-widget">

                          <img src="images/icons/target.png" align="center" alt="" class="text-center img-fluid ">
<br><br>
                        <h1><strong>Mission</strong></h1>
                        <p style="font-size:18px;text-align:left;color:darkslategray;font-weight:bold">Our goal is to
                            improve the environment through recycling, in collaboration with employees, 
                           business partners, government agencies & the general public to create a clean and safe 
                           place to live & work.<br><br><br></p>
                     </div>
                     <!-- end service -->
                  </div>
               </div>
            </div>
            <!-- end row -->
         </div>
         <!-- end container -->
      </div>
      <!-- end section -->
      <div class="sep1"></div>
      </div>
      <!-- end section -->


      <!-- owner start-->

      <div id="owner" class="section" >
         <div class="container">
            <div class="message-box ">
               <h2>From Management Desk</h2>
               </div>
            <div class="row">  
           <div class="col-md-4 text-center">
            <img src="uploads/1.jpg" style="border-radius:60%;" class="rounded float-left; ">
            <h3 style="padding-top:20px"> <strong>Mr. Nagnath D. Shinde</strong></h2>


           </div>

           <div class="col-md-8">

            <div class="message-box">
               <p class="lead" style="color:darkslategray;text-align:justify;font-weight:bold"><strong>Mr. Nagnath D. Shinde</strong> 
                  has more than 15 years of experience 
                  in <strong>scrap dealing</strong> . He is well known for offline dealing of scarp later on he decided
                  to expand his business & team & started online business of scrap . He is all india dealer of scrap
                   government approved dealer. </p>
               <!-- <a href="#" class="read-more">Read More</a> -->
            </div>


         </div>
            </div>
            
            <!-- end row -->
          
         </div>
    
      </div>

      <div class="section" >
         <div class="container">
            <div class="message-box ">
               <h2>License and Documents</h2>
               </div>

            <div class="row">
            
            <div class="col-md-4">
            
            <a href="images/documents/license.jpeg" data-rel="prettyPhoto[gal]" class=" global-radius">
            <button type="submit" value="SEND" id="submit" class="btn btn-light btn-radius grd1 btn-block" style="border-radius:20px"><br>Brothers<br> Scrap<br> Center<br> License<br><br></button>
            </a>

            </div>

            <div class="col-md-4">
            
            <a href="images/documents/enrollment.jpeg" data-rel="prettyPhoto[gal]" class=" global-radius">
            <button type="submit" value="SEND" id="submit" class="btn btn-light btn-radius text-left grd1 btn-block" style="border-radius:15px"><br>Maharastra<br> State<br> Tax<br> Certification<br><br></button>
            </a>

            </div>

            <div class="col-md-4">
            
            <a href="images/documents/udyam.jpeg" data-rel="prettyPhoto[gal]" class=" global-radius">
            <button type="submit" value="SEND" id="submit" class="btn btn-light btn-radius grd1 btn-block" style="border-radius:15px"><br>Udyam<br> Certifcate<br>Government <br>of India<br><br></button>
            </a>
            
            </div>
            </div>

      <div class="row">
      
      <div class="col-md-4" >
            
            <a href="images/documents/gst.jpg" data-rel="prettyPhoto[gal]" class=" global-radius">
            <button type="submit" value="SEND" id="submit" class="btn btn-light btn-radius grd1 btn-block" style="border-radius:15px"><br><br>GSTIN <br>Registered<br><br><br></button>
            </a>

            </div>

           

            <div class="col-md-4">
            
            <a href="images/documents/adhar.jpeg" data-rel="prettyPhoto[gal]" class=" global-radius">
            <button type="submit" value="SEND" id="submit" class="btn btn-light btn-radius grd1 btn-block" style="border-radius:15px"><br><br>Udyog<br> Aadhaar<br><br><br></button>
            </a>
            
            </div>
      
      </div>
          

           
         
</div>
</div>



     

      <div id="products" class="section">
      <div class="container">
         <div class="message-box ">
            <h2>Our Dealings</h2>
            <p  class="lead" style="color:darkslategray;font-weight:bold">We buy & sell  all scrap mostly machineries ,
             factories inventory , plastic , vehicle scrap , railway scrap after verification , JCB , metals non metals 
             etc .
      </p>
      
            </div>
 <div class="row">

         <div class="col-md-4 col-sm-12 col-xs-12" >
           
            <div class="row">
               <div class="service-widget" style="padding-right: 10px;padding-left: 10px;">
                  <div class="post-media wow fadeIn">
                     <a href="images/products/metalscrap.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="flaticon-unlink"></i></a>
                     <img src="images/products/metalscrap.jpg" alt="" class="img-responsive img-rounded">
                  </div>
                  <h3 style="text-align:center;color:darkslategray;font-weight:bold"> Metal Scrap</h3>
                  <!-- <p>Aliquam sagittis ligula et sem lacinia, ut facilisis enim sollicitudin. Proin nisi est, convallis nec purus vitae, iaculis posuere sapien. Cum sociis natoque.</p> -->
               </div>
               <!-- end service -->
            </div>
         </div>


         <div class="col-md-4 col-sm-12 col-xs-12">
            <div class="row">
               <div class="service-widget" style="padding-right: 10px;padding-left: 10px;">
                  <div class="post-media wow fadeIn">
                     <a href="images/products/metalmachine.jpeg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="flaticon-unlink"></i></a>
                     <img src="images/products/metalmachine.jpeg" alt="" class="img-responsive img-rounded">
                  </div>
                  <h3 style="text-align:center;color:darkslategray;font-weight:bold"> Machinery Metal Scrap</h3>
                  <!-- <p>Etiam materials ut mollis tellus, vel posuere nulla. Etiam sit amet lacus vitae massa sodales aliquam at eget quam. Integer ultricies et magna quis.</p> -->
               </div>
               <!-- end service -->
            </div>
         </div>

         <div class="col-md-4 col-sm-12 col-xs-12">
            <div class="row">
               <div class="service-widget" style="padding-right: 10px;padding-left: 10px;">
                  <div class="post-media wow fadeIn">
                     <a href="images/products/metalplastic.jpeg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="flaticon-unlink"></i></a>
                     <img src="images/products/metalplastic.jpeg" alt="" class="img-responsive img-rounded">
                  </div>
                  <h3 style="text-align:center;color:darkslategray;font-weight:bold"> Metal Plastic Scrap</h3>
                  <!-- <p>Etiam materials ut mollis tellus, vel posuere nulla. Etiam sit amet lacus vitae massa sodales aliquam at eget quam. Integer ultricies et magna quis.</p> -->
               </div>
               <!-- end service -->
            </div>
         </div>

       
      </div>

<div class="row">

<div class="col-md-4 col-sm-12 col-xs-12">
            <div class="row">
               <div class="service-widget" style="padding-right: 10px;padding-left: 10px;">
                  <div class="post-media wow fadeIn">
                     <a href="images/products/railway.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="flaticon-unlink"></i></a>
                     <img src="images/products/railway.jpg" alt="" class="img-responsive img-rounded">
                  </div>
                  <h3 style="text-align:center;color:darkslategray;font-weight:bold"> Railway Scrap</h3>
                  <!-- <p>Etiam materials ut mollis tellus, vel posuere nulla. Etiam sit amet lacus vitae massa sodales aliquam at eget quam. Integer ultricies et magna quis.</p> -->
               </div>
               <!-- end service -->
            </div>
         </div>

         <div class="col-md-4 col-sm-12 col-xs-12">
            <div class="row">
               <div class="service-widget" style="padding-right: 10px;padding-left: 10px;">
                  <div class="post-media wow fadeIn">
                     <a href="images/products/wind.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="flaticon-unlink"></i></a>
                     <img src="images/products/wind.jpg" alt="" class="img-responsive img-rounded">
                  </div>
                  <h3 style="text-align:center;color:darkslategray;font-weight:bold"> Wind turbin Scrap </h3>
                  <!-- <p>Etiam materials ut mollis tellus, vel posuere nulla. Etiam sit amet lacus vitae massa sodales aliquam at eget quam. Integer ultricies et magna quis.</p> -->
               </div>
               <!-- end service -->
            </div>
         </div>

         <div class="col-md-4 col-sm-12 col-xs-12">
            <div class="row">
               <div class="service-widget" style="padding-right: 10px;padding-left: 10px;">
                  <div class="post-media wow fadeIn">
                     <a href="images/products/plastic.jpeg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="flaticon-unlink"></i></a>
                     <img src="images/products/plastic.jpeg" alt="" class="img-responsive img-rounded">
                  </div>
                  <h3 style="text-align:center;color:darkslategray;font-weight:bold"> Plastic Scrap</h3>
                  <!-- <p>Duis at tellus at dui tincidunt scelerisque nec sed felis. Suspendisse id dolor sed leo rutrum euismod. Nullam vestibulum fermentum erat. It nam auctor. </p> -->
               </div>
               <!-- end service -->
            </div>
         </div>

           <div class="col-md-4 col-sm-12 col-xs-12">
            <div class="row">
               <div class="service-widget" style="padding-right: 10px;padding-left: 10px;">
                  <div class="post-media wow fadeIn">
                     <a href="images/products/machinery.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="flaticon-unlink"></i></a>
                     <img src="images/products/machinery.jpg" alt="" class="img-responsive img-rounded">
                  </div>
                  <h3 style="text-align:center;color:darkslategray;font-weight:bold"> Machinery Scrap</h3>
                  <!-- <p>Etiam materials ut mollis tellus, vel posuere nulla. Etiam sit amet lacus vitae massa sodales aliquam at eget quam. Integer ultricies et magna quis.</p> -->
               </div>
               <!-- end service -->
            </div>
         </div>


         <div class="col-md-4 col-sm-12 col-xs-12">
            <div class="row">
               <div class="service-widget" style="padding-right: 10px;padding-left: 10px;">
                  <div class="post-media wow fadeIn">
                     <a href="images/products/plasticmaterial.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="flaticon-unlink"></i></a>
                     <img src="images/products/plasticmaterial.jpg" alt="" class="img-responsive img-rounded">
                  </div>
                  <h3 style="text-align:center;color:darkslategray;font-weight:bold"> Plastic Material Scrap</h3>
                  <!-- <p>Etiam materials ut mollis tellus, vel posuere nulla. Etiam sit amet lacus vitae massa sodales aliquam at eget quam. Integer ultricies et magna quis.</p> -->
               </div>
               <!-- end service -->
            </div>
         </div>
</div>
   </div>
      </div>
     

  <!-- end section -->
  <div id="services" class="section"  >
   <div class="container">
      <div class="message-box">
         <h2>Work Process</h2>
         <h5 class="lead" style="color:darkslategray;text-align:justify;font-weight:bold">Scrap consists of recyclable materials 
            left over from product manufacturing & consumption, such as parts of vehicles, building supplies, 
            & surplus materials. Unlike waste, scrap has monetary value, especially recovered metals & 
            non-metallic materials are also recovered for recycling.If there is any scrap which includes steel,
            iron, plastic & all metals .
            They follow offline as well as online mode of process.
            </h5>
      </div>
      <div class="row">
         <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            
            <!-- end messagebox -->
         </div>
         <!-- <div class="col-lg-7 col-md-6 col-sm-12 col-xs-12">
            <div class="row">
               <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                  <div class="service-inform">
                     <div class="icon-service">
                        <img src="images/icon1.png" alt="#" />
                     </div>
                     <div class="service-inform-text">
                        <h3>Service One</h3>
                        <p>Contrary to popular belief, Lorem Ipsum is not simply random text.</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                  <div class="service-inform">
                     <div class="icon-service">
                        <img src="images/icon4.png" alt="#" />
                     </div>
                     <div class="service-inform-text">
                        <h3>Service Two</h3>
                        <p>Contrary to popular belief, Lorem Ipsum is not simply random text.</p>
                     </div>
                  </div>
               </div>
            </div>
         </div> -->
      </div>
   </div>
   <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="height:390px">
      <div class="row">
         <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 serv" style="background-color:#222;">
            <div class="serv-blog">
               <img src="images/icons/offline.png" alt="#" />
            </div>
            <div class="serv-blog-cont" >
               <h3>Offline Mode</h3>
               <p style="text-align:left">
                  > State availability<br>
                  > Physical verification of scrap<br>
                  > Quotation of scrap<br>
                  > Quality checking of scrap<br>
                  > Discussion on payment method<br>
                  > Final close</p>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 serv" style="background:#181818;height:420px">
            <div class="serv-blog">
               <img src="images/icons/i1.png" alt="#" />
            </div>
            <div class="serv-blog-cont">
               <h3>Online Mode</h3>
               <p style="text-align:left">
                  > Scrap metal recycling involves the recovery and processing of scrap metal<br>
                  > Online verification of scrap quality<br>
                  > Quotation from buyer and seller<br>
                  > Fixation of price<br>
                  > Final close
               </p>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 serv" style="background:#222;height:420px">
            <div class="serv-blog">
               <img src="images/icons/tender.png" alt="#" />
            </div>
            <div class="serv-blog-cont">
               <h3>Tenders</h3>
               <p style="text-align:left">
                  > Brother's Scrap Centre is well known for tender business<br>
                  > We apply for government tenders private tenders all over the India related to the scrap 
  
               </p>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- end section -->



<div id="gallery" class="section" style="padding-top:100px">
         <div class="container">
            <div class="row">
               <div class="col-lg-5 col-md-6 col-sm-12 col-xs-12">
                  <div class="message-box">
                     <h2>Our Gallery</h2>
                     <!-- <h5>Contrary to popular belief, Lorem Ipsum is not simply random text.</h5> -->
                  </div>
                  <!-- end messagebox -->
               </div>
               <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <div class="row">
                     <div class="container gal-container">
                        <div class="col-md-8 col-sm-12 co-xs-12 gal-item">
                           <div class="box">
                              <a href="#" data-toggle="modal" data-target="#1">
                              <img src="images/gallery/1.png" alt="#" />
                              </a>
                              <div class="modal fade" id="1" tabindex="-1" role="dialog">
                                 <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                       <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                       <div class="modal-body">
                                          <img src="images/gallery/1.png" alt="#" />
                                       </div>
                                       <div class="col-md-12 description">
                                          <h4>This is the first one on my Gallery</h4>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>

                        <div class="col-md-4 col-sm-6 co-xs-12 gal-item">
                           <div class="box">
                              <a href="#" data-toggle="modal" data-target="#2">
                              <img src="images/gallery/2.png" alt="#" />
                              </a>
                              <div class="modal fade" id="2" tabindex="-1" role="dialog">
                                 <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                       <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                       <div class="modal-body">
                                          <img src="images/gallery/2.png" alt="#" />
                                       </div>
                                       <div class="col-md-12 description">
                                          <h4>This is the second one on my Gallery</h4>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>

                        <div class="col-md-4 col-sm-6 co-xs-12 gal-item">
                           <div class="box">
                              <a href="#" data-toggle="modal" data-target="#3">
                              <img src="images/gallery/3.png" alt="#" />
                              </a>
                              <div class="modal fade" id="3" tabindex="-1" role="dialog">
                                 <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                       <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                       <div class="modal-body">
                                          <img src="images/gallery/3.png" alt="#" />
                                       </div>
                                       <div class="col-md-12 description">
                                          <h4>This is the third one on my Gallery</h4>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>

                        <div class="col-md-4 col-sm-6 co-xs-12 gal-item">
                           <div class="box">
                              <a href="#" data-toggle="modal" data-target="#4">
                              <img src="images/gallery/4.png" alt="#" />
                              </a>
                              <div class="modal fade" id="4" tabindex="-1" role="dialog">
                                 <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                       <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                       <div class="modal-body">
                                          <img src="images/gallery/4.png" alt="#" />
                                       </div>
                                       <div class="col-md-12 description">
                                          <h4>This is the fourth one on my Gallery</h4>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>

                        <div class="col-md-4 col-sm-6 co-xs-12 gal-item">
                           <div class="box">
                              <a href="#" data-toggle="modal" data-target="#5">
                              <img src="images/gallery/7.png" alt="#" />
                              </a>
                              <div class="modal fade" id="5" tabindex="-1" role="dialog">
                                 <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                       <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                       <div class="modal-body">
                                          <img src="images/gallery/7.png" alt="#" />
                                       </div>
                                       <div class="col-md-12 description">
                                          <h4>This is the fifth one on my Gallery</h4>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>

                        <div class="col-md-4 col-sm-6 co-xs-12 gal-item">
                           <div class="box">
                              <a href="#" data-toggle="modal" data-target="#6">
                              <img src="images/gallery/5.png" alt="#" />
                              </a>
                              <div class="modal fade" id="6" tabindex="-1" role="dialog">
                                 <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                       <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                       <div class="modal-body">
                                          <img src="images/gallery/5.png" alt="#" />
                                       </div>
                                       <div class="col-md-12 description">
                                          <h4>This is the ninth one on my Gallery</h4>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>

                        <div class="col-md-8 col-sm-12 co-xs-12 gal-item">
                           <div class="box">
                              <a href="#" data-toggle="modal" data-target="#7">
                              <img src="images/gallery/6.png" alt="#" />
                              </a>
                              <div class="modal fade" id="7" tabindex="-1" role="dialog">
                                 <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                       <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                       <div class="modal-body">
                                          <img src="images/gallery/6.png" alt="#" />
                                       </div>
                                       <div class="col-md-12 description">
                                          <h4>This is the tenth one on my Gallery</h4>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>

                        <div class="col-md-4 col-sm-6 co-xs-12 gal-item">
                           <div class="box">
                              <a href="#" data-toggle="modal" data-target="#8">
                              <img src="images/gallery/8.png" alt="#" />
                              </a>
                              <div class="modal fade" id="8" tabindex="-1" role="dialog">
                                 <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                       <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                       <div class="modal-body">
                                          <img src="images/gallery/8.png" alt="#" />
                                       </div>
                                       <div class="col-md-12 description">
                                          <h4>This is the ninth one on my Gallery</h4>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>

                        <div class="col-md-4 col-sm-6 co-xs-12 gal-item">
                           <div class="box">
                              <a href="#" data-toggle="modal" data-target="#9">
                              <img src="images/gallery/9.png" alt="#" />
                              </a>
                              <div class="modal fade" id="9" tabindex="-1" role="dialog">
                                 <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                       <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                       <div class="modal-body">
                                          <img src="images/gallery/9.png" alt="#" />
                                       </div>
                                       <div class="col-md-12 description">
                                          <h4>This is the ninth one on my Gallery</h4>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>

                        <div class="col-md-4 col-sm-6 co-xs-12 gal-item">
                           <div class="box">
                              <a href="#" data-toggle="modal" data-target="#10">
                              <img src="images/gallery/10.png" alt="#" />
                              </a>
                              <div class="modal fade" id="10" tabindex="-1" role="dialog">
                                 <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                       <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                       <div class="modal-body">
                                          <img src="images/gallery/10.png" alt="#" />
                                       </div>
                                       <div class="col-md-12 description">
                                          <h4>This is the ninth one on my Gallery</h4>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>

                        <div class="col-md-8 col-sm-6 co-xs-12 gal-item">
                           <div class="box">
                              <a href="#" data-toggle="modal" data-target="#11">
                              <img src="images/gallery/11.png" alt="#" />
                              </a>
                              <div class="modal fade" id="11" tabindex="-1" role="dialog">
                                 <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                       <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                       <div class="modal-body">
                                          <img src="images/gallery/11.png" alt="#" />
                                       </div>
                                       <div class="col-md-12 description">
                                          <h4>This is the ninth one on my Gallery</h4>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>


                        <div class="col-md-4 col-sm-6 co-xs-12 gal-item">
                           <div class="box">
                              <a href="#" data-toggle="modal" data-target="#12">
                              <img src="images/gallery/12.png" alt="#" />
                              </a>
                              <div class="modal fade" id="12" tabindex="-1" role="dialog">
                                 <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                       <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                       <div class="modal-body">
                                          <img src="images/gallery/12.png" alt="#" />
                                       </div>
                                       <div class="col-md-12 description">
                                          <h4>This is the ninth one on my Gallery</h4>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>





                        
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- end section -->

      <div id="price" class="section pr" >
         <div class="container">
            <div class="section-title row text-center">
               <div class="col-md-9 col-md-offset-2">
                  <h3>Get In Touch</h3>
                  <!-- <p class="lead">Quisque eget nisl id nulla sagittis auctor quis id. Aliquam quis vehicula enim, non aliquam risus. Sed a tellus quis mi rhoncus dignissim.</p> -->
               </div>
               <!-- end col -->
            </div>
            <!-- end title -->
            <div class="row">
               <div class="col-lg-8 col-md-4 p-0">
                  <div class="contant-info" >
                     <img src="images/icon.png"  alt="" class="img-fluid ">

                    <h2><strong>Environmental Rules</strong> </h2>
                    <p style="color:darkslategray;font-weight:bold"> We strictly follow environmental rules & 
                    government policies on climate change . Most of the scrap related to the plastic still we 
                    delivered to the businessman & the recycled it.</p>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="contact_form">
                     <div id="message"></div>
                     <form id="contactform" class="row" action="contactprocess.php" name="contactform" method="post">
                        <fieldset class="row-fluid">
                           <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                              <input type="text" name="name" id="first_name" class="form-control" required placeholder="Your Name" required>
                           </div>
                           <!-- <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                              <input type="text" name="last_name" id="last_name" class="form-control" placeholder="Last Name">
                           </div> -->
                           <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                              <input type="email" name="email" id="email" class="form-control" required placeholder="Your Email" required>
                           </div>
                           <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                              <input type="text" name="phone" id="phone" class="form-control" required placeholder="Your Contact Number">
                           </div>
                           <!-- <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                              <label class="sr-only">Select Service</label>
                              <select name="select_service" id="select_service" class="selectpicker form-control" data-style="btn-white">
                                 <option value="12">Select Service</option>
                                 <option value="Building Service">Building Service</option>
                                 <option value="Tover Design">Tover Design</option>
                                 <option value="Others">Others</option>
                              </select>
                           </div> -->
                           <div class="col-lg-12 col-md-6 col-sm-12 col-xs-12">
                              <textarea class="form-control" name="comments" id="comments" required rows="6" placeholder="Give us more details.."></textarea>
                           </div>
                           <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
                              <button type="submit" value="SEND" id="submit" class="btn btn-light btn-radius btn-brd grd1 btn-block">Send</button>
                           </div>
                        </fieldset>
                     </form>
                  </div>
               </div>
               <!-- end col -->
            </div>
            <!-- end row -->
         </div>
         <!-- end container -->
      </div>
      <!-- end section -->
   
           <!-- footer -->
           <footer id="footer">
            <div id="footer-widgets" class="container style-1">
               <div class="row">
                  <div class="col-md-4">
                     <div class="widget widget_text">
                        <!-- <h2 class="widget-title"><span>About Us</span></h2> -->
                        <div class="textwidget"><br>
                        <a class="navbar-brand" href="index.php"><img src="images/logo.png" alt="image"><span style="font-size:medium;" id="#margin">Brother's Scrap Center</span></a><br><br>
   
                        <!-- <span>Brother's Scrap Center</span></a> -->
                           <p>The Brother's Scrap Center has been  running since 10 years but between
                              couple of years it gain momentum and owner officially inaugurated this
                              firm in 2017-18 for the online and offline scrap dealing.</p>                        
                              </div>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="widget widget_links">
                        <h2 class="widget-title"><span>Quick Links</span></h2>
                        <ul class="wprt-links clearfix col2">
                           <li><a data-scroll="" href="#home">Home</a></li>
                           <li><a data-scroll="" href="#about">About us</a></li>
                           <li><a data-scroll="" href="#products">Dealings</a></li>
                           <li><a data-scroll="" href="#owner">Management</a></li>
                           <li><a data-scroll="" href="#services">Our Work</a></li>
                           <li><a data-scroll="" href="#gallery">Gallery</a></li>
                           <li><a data-scroll="" href="#price">Contact us</a></li>
                   </ul>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="widget widget_information">
                        <h2 class="widget-title"><span>Reach Us</span></h2>
                        <ul>
                           <li class="address clearfix">
                              <span class="hl">Address:</span> 
                              <span class="text">&nbsp;&nbsp;&nbsp;2 Sarvade Nagar,<br>
                                 &nbsp;&nbsp;&nbsp;Mulegon Road,
                                 <br>&nbsp;&nbsp;&nbsp;Near Yallamma Gas Pump,
                                <br> &nbsp;&nbsp;&nbsp;Solapur-413005</span>
                           </li>
                           <li class="phone clearfix">
                              <span class="hl">Phone:</span> 
                              <a style="color:#b7b7b7" href="tel:+91 8698719777"><span class="text">+91 8698719777</span></a>
   
                           </li>
                           <li class="email clearfix">
                              <span class="hl">E-mail:</span>
                              <a style="color:#b7b7b7" href="mailto:brothersshinde3777@gmail.com"><span class="text">brothersshinde3777@gmail.com</span></a>
   
                           </li>
                        </ul>
                     </div>
                     <!-- <div class="widget widget_socials">
                        <div class="socials">
                           <a target="_blank" href="#"><i class="fa fa-twitter"></i></a>
                           <a target="_blank" href="#"><i class="fa fa-facebook"></i></a>
                           <a target="_blank" href="#"><i class="fa fa-google-plus"></i></a>
                           <a target="_blank" href="#"><i class="fa fa-pinterest"></i></a>
                           <a target="_blank" href="#"><i class="fa fa-dribbble"></i></a>
                        </div>
                     </div> -->
                  </div>
               </div>
            </div>
            <div id="bottom" class="clearfix style-1">
               <div class="container">
                  <div id="bottom-bar-inner" class="wprt-container">
                     <div class="bottom-bar-inner-wrap">
                        <div class="bottom-bar-content text-center ">
                           <span class="text-center">Copyright © 2020 Designed & Developed By <a href="https://www.equireitpark.com/" style="text-decoration: none; color: white;" class="d-block d-sm-inline-block">Equire IT Park</a></span>

                           <!-- /#copyright -->
                        </div>
                        <!-- /.bottom-bar-content -->
                        <div class="bottom-bar-menu pull-right">
                           <!-- <ul class="bottom-nav">
                              <li><a href="#/">HISTORY</a></li>
                              <li><a href="#/">FAQ</a></li>
                              <li><a href="#/">EVENTS</a></li>
                           </ul> -->
                        </div>
                        <!-- /.bottom-bar-menu -->
                     </div>
                  </div>
               </div>
            </div>
         </footer>
         <!-- end footer -->
      
     
  
   </body>


   <script>
        $('.navbar-collapse a').click(function(){
            $(".navbar-collapse").collapse('hide');
        });
    </script>
   <script src="js/all.js"></script>
   <!-- ALL PLUGINS -->
   <script src="js/custom.js"></script>
   <script src="js/portfolio.js"></script>
   <script src="js/hoverdir.js"></script>   

   <!-- <script src="https://mdbootstrap.com/api/snippets/static/download/MDB-Pro_4.19.2/js/jquery.min.js"></script> -->
   <!-- <script src="https://mdbootstrap.com/api/snippets/static/download/MDB-Pro_4.19.2/js/popper.min.js"></script> -->
   <!-- <script src="https://mdbootstrap.com/api/snippets/static/download/MDB-Pro_4.19.2/js/bootstrap.min.js"></script> -->
   <!-- <script src="https://mdbootstrap.com/api/snippets/static/download/MDB-Pro_4.19.2/js/mdb.min.js"></script> -->
   <!-- <script src="https://mdbootstrap.com/wp-content/themes/mdbootstrap4/js/bundles/4.19.2/compiled-addons.min.js"></script> -->
</html>

