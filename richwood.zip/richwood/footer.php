<footer>
 <div class="footer-wrappper">
    <!-- Footer Start-->
    <div class="footer-area footer-padding">
        <div class="container">
            <div class="row">
                <div class="col-xl-5 col-lg-5 col-md-6 col-sm-8">
                    <div class="single-footer-caption mb-50">
                        <div class="single-footer-caption text-center">
                            <!-- logo -->
                            <div class="footer-logo">
                                <a href="index.php" ><img src="assets/images/footer.png" class="img-responsive" alt=""></a><br><br><br>
                                <a href="index.php" ><img src="assets/images/footerlogo.png" class="img-fluid" alt=""></a>
                       
                                <h4 style="font-size:20px"><strong>Enriching Lives Through Innovations</strong></h4>
                            </div>

                          
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-4">
                    <div class="single-footer-caption mb-50">
                        <div class="footer-tittle">
                            <h4>Quick Links</h4>
                            <ul>
                                       <li><a href="index.php">Home</a></li>
                                       <li><a href="about.php">About</a></li>
                                       <li><a href="products.php">Products</a></li>
                                       <!-- <li><a href="media.php">Showcase</a></li>
                                       <li><a href="partners.php">Partners</a></li> -->
                                       <li><a href="contact.php">Contact</a></li>
                         </ul>
                        </div>

                        <div class="footer-social pt-4">
                    <a href="https://api.whatsapp.com/send?phone=+91 7722066777"><i class="fab fa-whatsapp fa-lg"></i></a>
                    <a href="https://www.linkedin.com/in/hrishikesh-badamikar-94671414"><i class="fab fa-linkedin"></i></a>
                    <a href="https://www.facebook.com/Richwood-Industries-PvtLtd-110708783879951/"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://www.youtube.com/channel/UCy9knsUtXjwZ1Z_otaVNX1w"><i class="fab fa-youtube"></i></a>
               
                                   </div>
                    </div>
                </div>

                
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
                    <div class="single-footer-caption mb-50">
                    <div class="footer-tittle">
                            <h4>Reach Us</h4>
                              <p>Plot No. 37, Industrial Estate,<br> Hotgi Road, Solapur - 413003. Maharashtra, INDIA.</p>  
                            <h4>Contact Us</h4>
                
                            <a href="https://api.whatsapp.com/send?phone=+91 7722066777" style="color:#634833"> <i class="fab fa-whatsapp fa-lg" aria-hidden="true"></i> +91 7722066777</a><br>
                            <a href="mailto:rich_wood@rediffmail.com" style="color:#634833"> <i class="far fa-envelope" aria-hidden="true"></i> rich_wood@rediffmail.com</a><br>
                            <a href="mailto:info@richfill.in" style="color:#634833"> <i class="far fa-envelope" aria-hidden="true"></i> info@richfill.in</a>

         
                        </div>

                    </div>

                </div>
                <marquee behavior="scroll" loop="infinite" direction="left" scrollamount="7">

                <img src="assets/images/partner/1.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/2.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/3.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/4.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/5.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/6.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/7.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/8.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/9.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/10.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/11.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/12.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/13.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/14.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/15.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/16.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/17.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/18.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/19.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/20.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/21.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/22.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/23.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/24.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/25.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/26.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/27.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/28.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/29.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                <img src="assets/images/partner/30.png"   alt="Responsive image"style="height:80px"/>&nbsp;&nbsp;&nbsp;
                
              
                    
 </marquee>
            </div>
        </div>
    </div>
    <!-- footer-bottom area -->
    <div class="footer-bottom-area">
        <div class="container">
            <div class="footer-border">
                <div class="row d-flex align-items-center">
                    <div class="col-xl-12 ">
                        <div class="footer-copy-right text-center">
                            <p style="color: #3f2021"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Designed and Developed By <a style="color: #571715" href="https://equireitpark.com" target="_blank"><strong>Equire IT Park</strong></a>
                              <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>


                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
      <!-- Footer End-->
  </div>
</footer>