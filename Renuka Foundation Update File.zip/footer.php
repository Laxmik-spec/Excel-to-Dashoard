

<footer>
        <div class="footer-top">
			<div class="pt-exebar">
				<div class="container">
					<div class="d-flex align-items-stretch">
					<div class="menu-logo p-3" >
						<a href="index.php" ><img src="assets/images/logo_white.png"  class="img-fluid" style="float:left" alt=""></a>
					</div>

						<div class="pt-btn-join">
							<!-- <a href="#" class="btn ">Join Now</a> -->
						</div>
					</div>
				</div>
			</div>
            <div class="container">
                <div class="row">
					<div class="col-lg-4 col-md-12 col-sm-12 footer-col-4">
                        <div class="widget">
                            <h5 class="footer-title">Better Education For A Better Life</h5>
							<!-- <p class="text-capitalize m-b20">Better Education For A Better Life</p> -->
							<div class="pt-social-link">
							<ul class="list-inline">
								<li><a href="#" class="btn-link"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#" class="btn-link"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#" class="btn-link"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="#" class="btn-link"><i class="fa fa-google-plus"></i></a></li>
							</ul>
						</div>
                            <!-- <div class="subscribe-form m-b20">
								<form class="subscription-form" action="http://educhamp.themetrades.com/demo/assets/script/mailchamp.php" method="post">
									<div class="ajax-message"></div>

								</form>
							</div> -->
                        </div>
                    </div>
					<div class="col-12 col-lg-5 col-md-7 col-sm-12">
						<div class="row">

							<div class="col-4 col-lg-4 col-md-4 col-sm-4">
								<div class="widget footer_widget">
                                <h5 class="footer-title">Quick Links</h5>
									<ul>
										<li><a href="index.php">Home</a></li>
                                        <li><a href="about-us.php">About Us</a></li>
										<li><a href="renuka-foundation.php">Institutes</a></li>
										<li><a href="staff.php">Management</a></li>
										<li><a href="gallery.php">Gallery</a></li>
                                       
										<!-- <li><a href="faq-1.html">FAQs</a></li> -->
										<li><a href="contact-us.php">Contact Us</a></li>
									</ul>
								</div>
							</div>
							<div class="col-4 col-lg-4 col-md-4 col-sm-4">
								<div class="widget footer_widget">
                                <h5 class="footer-title">Courses</h5>
									<ul>
										<li><a href="courses.php">All Courses</a></li>

									</ul>
								</div>
							</div>
						</div>
                    </div>
					<div class="col-12 col-lg-3 col-md-5 col-sm-12 footer-col-4">
                        <div class="widget widget_gallery gallery-grid-4">
                            <h5 class="footer-title" ><a href="gallery.php" style="color:#fff">Our Gallery</a></h5>
                            <ul class="magnific-image">
								<li><a href="assets/images/photos/paramedic/paramedic 1.jpeg" class="magnific-anchor"><img src="assets/images/photos/paramedic/paramedic 1.jpeg" alt=""></a></li>
								<li><a href="assets/images/photos/paramedic/paramedic 3.jpeg" class="magnific-anchor"><img src="assets/images/photos/paramedic/paramedic 3.jpeg" alt=""></a></li>
								<li><a href="assets/images/photos/nursing/nursing 1.jpeg" class="magnific-anchor"><img src="assets/images/photos/nursing/nursing 1.jpeg" alt=""></a></li>
								<li><a href="assets/images/photos/nursing/nursing 2.jpeg" class="magnific-anchor"><img src="assets/images/photos/nursing/nursing 2.jpeg" alt=""></a></li>
								<li><a href="assets/images/photos/nursing/nursing 5.jpeg" class="magnific-anchor"><img src="assets/images/photos/nursing/nursing 5.jpeg" alt=""></a></li>
								<li><a href="assets/images/photos/class/class 21.jpeg" class="magnific-anchor"><img src="assets/images/photos/class/class 21.jpeg" alt=""></a></li>
								<li><a href="assets/images/photos/class/class 19.jpeg" class="magnific-anchor"><img src="assets/images/photos/class/class 19.jpeg" alt=""></a></li>
								<li><a href="assets/images/photos/class/class 16.jpeg" class="magnific-anchor"><img src="assets/images/photos/class/class 16.jpeg" alt=""></a></li>
							</ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 text-center" style="color:#fff">Copyright &copy;<script>document.write(new Date().getFullYear());</script> <strong style="color:#fff"><a>Renuka Group of Foundation</strong></a> Designed & Developed By <strong><a target="_blank" href="https://www.equireitpark.com/">Equire IT Park</strong></a></div>
                </div>
            </div>
        </div>
    </footer>

